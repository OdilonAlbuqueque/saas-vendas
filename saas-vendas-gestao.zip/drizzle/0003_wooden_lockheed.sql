ALTER TABLE `sales` ADD `isCancelled` boolean DEFAULT false NOT NULL;--> statement-breakpoint
ALTER TABLE `sales` ADD `cancellationReason` text;--> statement-breakpoint
ALTER TABLE `sales` ADD `cancelledAt` timestamp;