CREATE TABLE `payable_accounts` (
	`id` int AUTO_INCREMENT NOT NULL,
	`companyId` int NOT NULL,
	`contactName` varchar(255) NOT NULL,
	`description` text,
	`category` varchar(100) NOT NULL,
	`dueDate` date NOT NULL,
	`competenceDate` date NOT NULL,
	`value` decimal(12,2) NOT NULL,
	`status` enum('pending','paid','overdue') NOT NULL DEFAULT 'pending',
	`contactType` varchar(50) DEFAULT 'supplier',
	`costCenter` varchar(255),
	`notes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `payable_accounts_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `receivable_accounts` (
	`id` int AUTO_INCREMENT NOT NULL,
	`companyId` int NOT NULL,
	`contactName` varchar(255) NOT NULL,
	`description` text,
	`category` varchar(100) NOT NULL,
	`dueDate` date NOT NULL,
	`competenceDate` date NOT NULL,
	`value` decimal(12,2) NOT NULL,
	`status` enum('pending','received','overdue') NOT NULL DEFAULT 'pending',
	`contactType` varchar(50) DEFAULT 'client',
	`costCenter` varchar(255),
	`notes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `receivable_accounts_id` PRIMARY KEY(`id`)
);
