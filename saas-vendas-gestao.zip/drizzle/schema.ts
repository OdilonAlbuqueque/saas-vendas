import { int, mysqlEnum, mysqlTable, text, timestamp, varchar, decimal, boolean, date, index, unique, json } from "drizzle-orm/mysql-core";

/**
 * Tabelas do Sistema SaaS de Gestão de Vendas
 * Estrutura multi-empresa com isolamento de dados por companyId
 */

// ==================== TABELAS PRINCIPAIS ====================

export const companies = mysqlTable("companies", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  document: varchar("document", { length: 20 }).notNull().unique(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Company = typeof companies.$inferSelect;
export type InsertCompany = typeof companies.$inferInsert;

export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  companyId: int("companyId").notNull(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  password: varchar("password", { length: 255 }).notNull(),
  passwordSet: boolean("passwordSet").default(false).notNull(),
  loginMethod: varchar("loginMethod", { length: 64 }).default("local"),
  role: mysqlEnum("role", ["user", "admin", "digital_sales", "super_admin"]).default("user").notNull(),
  storeId: int("storeId"), // Loja fixa para usuários comuns
  isActive: boolean("isActive").default(true).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

export const stores = mysqlTable("stores", {
  id: int("id").autoincrement().primaryKey(),
  companyId: int("companyId").notNull(),
  name: varchar("name", { length: 255 }).notNull(),
  location: text("location"),
  isActive: boolean("isActive").default(true).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Store = typeof stores.$inferSelect;
export type InsertStore = typeof stores.$inferInsert;

export const machines = mysqlTable("machines", {
  id: int("id").autoincrement().primaryKey(),
  companyId: int("companyId").notNull(),
  name: varchar("name", { length: 255 }).notNull(),
  commissionValue: decimal("commissionValue", { precision: 10, scale: 2 }).notNull(),
  isActive: boolean("isActive").default(true).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Machine = typeof machines.$inferSelect;
export type InsertMachine = typeof machines.$inferInsert;

export const salesOrigins = mysqlTable("salesOrigins", {
  id: int("id").autoincrement().primaryKey(),
  companyId: int("companyId").notNull(),
  name: varchar("name", { length: 255 }).notNull(),
  isActive: boolean("isActive").default(true).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type SalesOrigin = typeof salesOrigins.$inferSelect;
export type InsertSalesOrigin = typeof salesOrigins.$inferInsert;

export const hashtagOrigins = mysqlTable("hashtagOrigins", {
  id: int("id").autoincrement().primaryKey(),
  companyId: int("companyId").notNull(),
  name: varchar("name", { length: 255 }).notNull(),
  isActive: boolean("isActive").default(true).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type HashtagOrigin = typeof hashtagOrigins.$inferSelect;
export type InsertHashtagOrigin = typeof hashtagOrigins.$inferInsert;

export const sales = mysqlTable("sales", {
  id: int("id").autoincrement().primaryKey(),
  companyId: int("companyId").notNull(),
  userId: int("userId").notNull(),
  serialNumber: varchar("serialNumber", { length: 255 }).notNull(),
  clientName: varchar("clientName", { length: 255 }).notNull(),
  clientDocument: varchar("clientDocument", { length: 20 }).notNull(),
  storeId: int("storeId").notNull(),
  machineId: int("machineId").notNull(),
  saleDate: timestamp("saleDate").notNull(),
  isDelivery: boolean("isDelivery").default(false).notNull(),
  deliveryValue: decimal("deliveryValue", { precision: 10, scale: 2 }),
  salesOriginId: int("salesOriginId").notNull(),
  hashtagOriginId: int("hashtagOriginId").notNull(),
  commissionValue: decimal("commissionValue", { precision: 10, scale: 2 }).notNull(),
  isCancelled: boolean("isCancelled").default(false).notNull(),
  cancellationReason: text("cancellationReason"),
  cancelledAt: timestamp("cancelledAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Sale = typeof sales.$inferSelect;
export type InsertSale = typeof sales.$inferInsert;

// ==================== CONTAS A PAGAR ====================

export const payableAccounts = mysqlTable("payable_accounts", {
  id: int("id").autoincrement().primaryKey(),
  companyId: int("companyId").notNull(),
  contactName: varchar("contactName", { length: 255 }).notNull(),
  description: text("description"),
  category: varchar("category", { length: 100 }).notNull(),
  dueDate: date("dueDate").notNull(),
  competenceDate: date("competenceDate").notNull(),
  value: decimal("value", { precision: 12, scale: 2 }).notNull(),
  status: mysqlEnum("status", ["pending", "paid", "overdue"]).default("pending").notNull(),
  contactType: varchar("contactType", { length: 50 }).default("supplier"),
  costCenter: varchar("costCenter", { length: 255 }),
  notes: text("notes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type PayableAccount = typeof payableAccounts.$inferSelect;
export type InsertPayableAccount = typeof payableAccounts.$inferInsert;

// ==================== CONTAS A RECEBER ====================

export const receivableAccounts = mysqlTable("receivable_accounts", {
  id: int("id").autoincrement().primaryKey(),
  companyId: int("companyId").notNull(),
  contactName: varchar("contactName", { length: 255 }).notNull(),
  description: text("description"),
  category: varchar("category", { length: 100 }).notNull(),
  dueDate: date("dueDate").notNull(),
  competenceDate: date("competenceDate").notNull(),
  value: decimal("value", { precision: 12, scale: 2 }).notNull(),
  status: mysqlEnum("status", ["pending", "received", "overdue"]).default("pending").notNull(),
  contactType: varchar("contactType", { length: 50 }).default("client"),
  costCenter: varchar("costCenter", { length: 255 }),
  notes: text("notes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type ReceivableAccount = typeof receivableAccounts.$inferSelect;
export type InsertReceivableAccount = typeof receivableAccounts.$inferInsert;

// ==================== TABELAS MULTI-TENANT ====================

export const tenants = mysqlTable("tenants", {
  id: varchar("id", { length: 36 }).primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  slug: varchar("slug", { length: 255 }).notNull().unique(),
  email: varchar("email", { length: 320 }).notNull(),
  phone: varchar("phone", { length: 20 }),
  status: mysqlEnum("status", ["active", "inactive", "suspended"]).default("active").notNull(),
  user_limit: int("user_limit").default(5).notNull(),
  schema_name: varchar("schema_name", { length: 255 }).notNull().unique(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Tenant = typeof tenants.$inferSelect;
export type InsertTenant = typeof tenants.$inferInsert;

export const tenantUsers = mysqlTable("tenant_users", {
  id: varchar("id", { length: 36 }).primaryKey(),
  tenantId: varchar("tenantId", { length: 36 }).notNull(),
  userId: int("userId").notNull(),
  role: mysqlEnum("role", ["super_admin", "admin", "user", "vendor"]).default("user").notNull(),
  status: mysqlEnum("status", ["active", "inactive"]).default("active").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => ({
  tenantIdIdx: index("tenantId_idx").on(table.tenantId),
  userIdIdx: index("userId_idx").on(table.userId),
  uniqueTenantUser: unique("unique_tenant_user").on(table.tenantId, table.userId),
}));

export type TenantUser = typeof tenantUsers.$inferSelect;
export type InsertTenantUser = typeof tenantUsers.$inferInsert;

export const tenantRoles = mysqlTable("tenant_roles", {
  id: varchar("id", { length: 36 }).primaryKey(),
  tenantId: varchar("tenantId", { length: 36 }).notNull(),
  name: varchar("name", { length: 255 }).notNull(),
  permissions: text("permissions"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type TenantRole = typeof tenantRoles.$inferSelect;
export type InsertTenantRole = typeof tenantRoles.$inferInsert;
