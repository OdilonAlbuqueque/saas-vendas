ALTER TABLE `tenants` ADD `schema_name` varchar(255) NOT NULL;--> statement-breakpoint
ALTER TABLE `tenants` ADD CONSTRAINT `tenants_schema_name_unique` UNIQUE(`schema_name`);