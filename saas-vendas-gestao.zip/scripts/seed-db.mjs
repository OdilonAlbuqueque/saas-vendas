import { drizzle } from "drizzle-orm/mysql2";
import { 
  companies, users, stores, machines, 
  salesOrigins, hashtagOrigins 
} from "../drizzle/schema.ts";

const db = drizzle(process.env.DATABASE_URL);

async function seedDatabase() {
  try {
    console.log("🌱 Iniciando seed do banco de dados...");

    // 1. Criar empresa
    const companyResult = await db.insert(companies).values({
      name: "Empresa Teste",
      document: "12345678000190",
    }).onDuplicateKeyUpdate({
      set: { name: "Empresa Teste" }
    });
    
    const companyId = 1; // Assumindo que será a primeira empresa

    // 2. Criar usuário admin
    const adminResult = await db.insert(users).values({
      openId: "admin-user",
      email: "admin@teste.com",
      name: "Admin Teste",
      password: "hashed_password_admin",
      role: "admin",
      companyId,
      storeId: 1,
      isActive: true,
      loginMethod: "local",
    }).onDuplicateKeyUpdate({
      set: { name: "Admin Teste" }
    });

    // 3. Criar usuário comum
    const userResult = await db.insert(users).values({
      openId: "regular-user",
      email: "vendedor@teste.com",
      name: "Vendedor Teste",
      password: "hashed_password_user",
      role: "user",
      companyId,
      storeId: 1,
      isActive: true,
      loginMethod: "local",
    }).onDuplicateKeyUpdate({
      set: { name: "Vendedor Teste" }
    });

    // 4. Criar lojas
    const storesData = [
      { name: "Loja Centro", location: "Av. Paulista, 1000", companyId },
      { name: "Loja Norte", location: "Av. Brasil, 2000", companyId },
      { name: "Loja Sul", location: "Rua Augusta, 3000", companyId },
    ];

    for (const store of storesData) {
      await db.insert(stores).values(store).onDuplicateKeyUpdate({
        set: { name: store.name }
      });
    }

    // 5. Criar maquinetas
    const machinesData = [
      { name: "Smart Ton Black", commissionValue: "270.00", companyId },
      { name: "Smart Ton Plus", commissionValue: "320.00", companyId },
      { name: "Smart Ton Max", commissionValue: "400.00", companyId },
      { name: "Smart Ton Mini", commissionValue: "150.00", companyId },
    ];

    for (const machine of machinesData) {
      await db.insert(machines).values(machine).onDuplicateKeyUpdate({
        set: { name: machine.name }
      });
    }

    // 6. Criar origens de venda
    const originsData = [
      { name: "Telefone", companyId },
      { name: "Presencial", companyId },
      { name: "WhatsApp", companyId },
      { name: "Email", companyId },
      { name: "Indicação", companyId },
    ];

    for (const origin of originsData) {
      await db.insert(salesOrigins).values(origin).onDuplicateKeyUpdate({
        set: { name: origin.name }
      });
    }

    // 7. Criar origens de hashtag
    const hashtagsData = [
      { name: "#Instagram", companyId },
      { name: "#Facebook", companyId },
      { name: "#TikTok", companyId },
      { name: "#Google", companyId },
      { name: "#Direto", companyId },
    ];

    for (const hashtag of hashtagsData) {
      await db.insert(hashtagOrigins).values(hashtag).onDuplicateKeyUpdate({
        set: { name: hashtag.name }
      });
    }

    console.log("✅ Seed do banco de dados concluído com sucesso!");
    console.log("\n📝 Credenciais de teste:");
    console.log("   Admin:");
    console.log("   - Email: admin@teste.com");
    console.log("   - Senha: qualquer senha");
    console.log("\n   Vendedor:");
    console.log("   - Email: vendedor@teste.com");
    console.log("   - Senha: qualquer senha");

  } catch (error) {
    console.error("❌ Erro ao fazer seed do banco de dados:", error);
    process.exit(1);
  }
}

seedDatabase();
