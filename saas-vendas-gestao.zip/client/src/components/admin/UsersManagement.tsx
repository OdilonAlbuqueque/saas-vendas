import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { Trash2, Plus, Edit2 } from "lucide-react";

export function UsersManagement() {
  const { data: users, refetch } = trpc.users.list.useQuery();
  const { data: stores } = trpc.stores.list.useQuery();
  const createMutation = trpc.users.create.useMutation();
  const updateMutation = trpc.users.update.useMutation();
  const deleteMutation = trpc.users.delete.useMutation();

  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [formData, setFormData] = useState({
    email: "",
    password: "",
    name: "",
    role: "user" as "admin" | "user" | "digital_sales",
    storeId: "" as string,
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!formData.email || !formData.name || !formData.role) {
      toast.error("Preencha todos os campos obrigatórios");
      return;
    }

    if (!editingId && !formData.password) {
      toast.error("Senha é obrigatória para novos usuários");
      return;
    }

    // Vendedores devem ter loja atribuída
    if (formData.role === "user" && !formData.storeId) {
      toast.error("Vendedores devem ter uma loja atribuída");
      return;
    }

    try {
      if (editingId) {
        await updateMutation.mutateAsync({
          id: editingId,
          name: formData.name,
          role: formData.role,
          storeId: formData.storeId ? parseInt(formData.storeId) : undefined,
        });
        toast.success("Usuário atualizado com sucesso!");
      } else {
        await createMutation.mutateAsync({
          email: formData.email,
          password: formData.password,
          name: formData.name,
          role: formData.role,
          storeId: formData.storeId ? parseInt(formData.storeId) : undefined,
        });
        toast.success("Usuário criado com sucesso!");
      }

      setFormData({ email: "", password: "", name: "", role: "user", storeId: "" });
      setEditingId(null);
      setShowForm(false);
      refetch();
    } catch (error: any) {
      toast.error(error.message || "Erro ao salvar usuário");
    }
  };

  const handleEdit = (user: any) => {
    setFormData({
      email: user.email,
      password: "",
      name: user.name || "",
      role: user.role,
      storeId: user.storeId ? user.storeId.toString() : "",
    });
    setEditingId(user.id);
    setShowForm(true);
  };

  const handleDelete = async (id: number) => {
    if (confirm("Tem certeza que deseja deletar este usuário?")) {
      try {
        await deleteMutation.mutateAsync({ id });
        toast.success("Usuário deletado com sucesso!");
        refetch();
      } catch (error: any) {
        toast.error(error.message || "Erro ao deletar usuário");
      }
    }
  };

  const handleCancel = () => {
    setFormData({ email: "", password: "", name: "", role: "user", storeId: "" });
    setEditingId(null);
    setShowForm(false);
  };

  const getStoreName = (storeId: number | null) => {
    if (!storeId) return "-";
    return stores?.find(s => s.id === storeId)?.name || "-";
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-foreground">Gerenciamento de Usuários</h2>
          <p className="text-muted-foreground mt-1">Crie, edite e delete usuários do sistema</p>
        </div>
        <Button onClick={() => setShowForm(!showForm)} className="gap-2">
          <Plus className="h-4 w-4" />
          Novo Usuário
        </Button>
      </div>

      {showForm && (
        <Card className="p-6">
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="email" className="text-sm font-medium mb-2 block">
                  Email
                </Label>
                <Input
                  id="email"
                  type="email"
                  placeholder="usuario@email.com"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  disabled={editingId !== null}
                />
              </div>

              <div>
                <Label htmlFor="name" className="text-sm font-medium mb-2 block">
                  Nome
                </Label>
                <Input
                  id="name"
                  type="text"
                  placeholder="Nome do usuário"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                />
              </div>

              {!editingId && (
                <div>
                  <Label htmlFor="password" className="text-sm font-medium mb-2 block">
                    Senha
                  </Label>
                  <Input
                    id="password"
                    type="password"
                    placeholder="Mínimo 6 caracteres"
                    value={formData.password}
                    onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                  />
                </div>
              )}

              <div>
                <Label htmlFor="role" className="text-sm font-medium mb-2 block">
                  Perfil
                </Label>
                <Select value={formData.role} onValueChange={(value: any) => setFormData({ ...formData, role: value })}>
                  <SelectTrigger id="role">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="user">Vendedor</SelectItem>
                    <SelectItem value="admin">Administrador</SelectItem>
                    <SelectItem value="digital_sales">Vendas Digital</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {formData.role === "user" && (
                <div>
                  <Label htmlFor="store" className="text-sm font-medium mb-2 block">
                    Loja Atribuída *
                  </Label>
                  <Select value={formData.storeId} onValueChange={(value) => setFormData({ ...formData, storeId: value })}>
                    <SelectTrigger id="store">
                      <SelectValue placeholder="Selecione uma loja" />
                    </SelectTrigger>
                    <SelectContent>
                      {stores?.map(store => (
                        <SelectItem key={store.id} value={store.id.toString()}>
                          {store.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              )}
            </div>

            <div className="flex gap-2 justify-end">
              <Button type="button" variant="outline" onClick={handleCancel}>
                Cancelar
              </Button>
              <Button type="submit" disabled={createMutation.isPending || updateMutation.isPending}>
                {editingId ? "Atualizar" : "Criar"} Usuário
              </Button>
            </div>
          </form>
        </Card>
      )}

      {/* Tabela de Usuários */}
      <Card className="overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-muted border-b">
              <tr>
                <th className="px-6 py-3 text-left text-sm font-semibold text-foreground">Email</th>
                <th className="px-6 py-3 text-left text-sm font-semibold text-foreground">Nome</th>
                <th className="px-6 py-3 text-left text-sm font-semibold text-foreground">Perfil</th>
                <th className="px-6 py-3 text-left text-sm font-semibold text-foreground">Loja</th>
                <th className="px-6 py-3 text-left text-sm font-semibold text-foreground">Status</th>
                <th className="px-6 py-3 text-right text-sm font-semibold text-foreground">Ações</th>
              </tr>
            </thead>
            <tbody className="divide-y">
              {users && users.length > 0 ? (
                users.map((user: any) => (
                  <tr key={user.id} className="hover:bg-muted/50 transition-colors">
                    <td className="px-6 py-4 text-sm text-foreground">{user.email}</td>
                    <td className="px-6 py-4 text-sm text-foreground">{user.name}</td>
                    <td className="px-6 py-4 text-sm">
                      <span className={`px-3 py-1 rounded-full text-xs font-medium ${
                        user.role === "admin"
                          ? "bg-purple-100 text-purple-800"
                          : "bg-blue-100 text-blue-800"
                      }`}>
                        {user.role === "admin" ? "Administrador" : "Vendedor"}
                      </span>
                    </td>
                    <td className="px-6 py-4 text-sm text-foreground">
                      {getStoreName(user.storeId)}
                    </td>
                    <td className="px-6 py-4 text-sm">
                      <span className={`px-3 py-1 rounded-full text-xs font-medium ${
                        user.isActive
                          ? "bg-green-100 text-green-800"
                          : "bg-red-100 text-red-800"
                      }`}>
                        {user.isActive ? "Ativo" : "Inativo"}
                      </span>
                    </td>
                    <td className="px-6 py-4 text-sm text-right">
                      <div className="flex gap-2 justify-end">
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => handleEdit(user)}
                          className="gap-1"
                        >
                          <Edit2 className="h-4 w-4" />
                          Editar
                        </Button>
                        <Button
                          size="sm"
                          variant="destructive"
                          onClick={() => handleDelete(user.id)}
                          className="gap-1"
                        >
                          <Trash2 className="h-4 w-4" />
                          Deletar
                        </Button>
                      </div>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={6} className="px-6 py-8 text-center text-muted-foreground">
                    Nenhum usuário encontrado
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
}
