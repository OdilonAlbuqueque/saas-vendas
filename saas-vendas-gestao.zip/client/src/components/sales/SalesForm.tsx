import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { toast } from "sonner";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { Loader2 } from "lucide-react";

export default function SalesForm() {
  const { user } = useAuth();
  const [formData, setFormData] = useState({
    serialNumber: "",
    clientName: "",
    clientDocument: "",
    storeId: "",
    machineId: "",
    saleDate: new Date().toISOString().split("T")[0],
    isDelivery: false,
    deliveryValue: "",
    salesOriginId: "",
    hashtagOriginId: "",
  });

  const [isLoading, setIsLoading] = useState(false);

  // Fetch data
  const { data: stores } = trpc.stores.list.useQuery();
  const { data: machines } = trpc.machines.list.useQuery();
  const { data: salesOrigins } = trpc.salesOrigins.list.useQuery();
  const { data: hashtagOrigins } = trpc.hashtagOrigins.list.useQuery();

  const createSaleMutation = trpc.sales.create.useMutation();

  // Se for vendedor, congelar a loja atribuída
  useEffect(() => {
    if (user?.role === "user" && user?.storeId && !formData.storeId) {
      setFormData(prev => ({
        ...prev,
        storeId: (user.storeId as number).toString(),
      }));
    }
  }, [user, formData.storeId]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value, type, checked } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: type === "checkbox" ? checked : value,
    }));
  };

  const handleSelectChange = (name: string, value: string) => {
    setFormData(prev => ({
      ...prev,
      [name]: value,
    }));
  };

  const validateForm = (): boolean => {
    if (!formData.serialNumber.trim()) {
      toast.error("Serial Number é obrigatório");
      return false;
    }
    if (!formData.clientName.trim()) {
      toast.error("Nome do Cliente é obrigatório");
      return false;
    }
    if (!formData.clientDocument.trim() || !/^\d+$/.test(formData.clientDocument)) {
      toast.error("Documento do Cliente deve conter apenas números");
      return false;
    }
    if (!formData.storeId) {
      toast.error("Loja é obrigatória");
      return false;
    }
    if (!formData.machineId) {
      toast.error("Maquineta é obrigatória");
      return false;
    }
    if (!formData.salesOriginId) {
      toast.error("Origem da Venda é obrigatória");
      return false;
    }
    if (!formData.hashtagOriginId) {
      toast.error("Origem da Hashtag é obrigatória");
      return false;
    }
    if (formData.isDelivery && !formData.deliveryValue) {
      toast.error("Valor da Entrega é obrigatório para entregas");
      return false;
    }
    return true;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) return;

    setIsLoading(true);
    try {
      const saleDate = new Date(formData.saleDate);
      
      await createSaleMutation.mutateAsync({
        serialNumber: formData.serialNumber,
        clientName: formData.clientName,
        clientDocument: formData.clientDocument,
        storeId: parseInt(formData.storeId),
        machineId: parseInt(formData.machineId),
        saleDate,
        isDelivery: formData.isDelivery,
        deliveryValue: formData.isDelivery ? parseFloat(formData.deliveryValue) : undefined,
        salesOriginId: parseInt(formData.salesOriginId),
        hashtagOriginId: parseInt(formData.hashtagOriginId),
      });

      toast.success("Venda registrada com sucesso!");
      
      // Reset form
      setFormData({
        serialNumber: "",
        clientName: "",
        clientDocument: "",
        storeId: user?.role === "user" && user?.storeId ? user.storeId.toString() : "",
        machineId: "",
        saleDate: new Date().toISOString().split("T")[0],
        isDelivery: false,
        deliveryValue: "",
        salesOriginId: "",
        hashtagOriginId: "",
      });
    } catch (error: any) {
      toast.error(error.message || "Erro ao registrar venda");
    } finally {
      setIsLoading(false);
    }
  };

  const isVendor = user?.role === "user";
  const userStoreName = isVendor && user?.storeId 
    ? stores?.find(s => s.id === (user.storeId as number))?.name 
    : null;

  return (
    <Card className="p-6">
      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* Serial Number */}
          <div>
            <Label htmlFor="serialNumber">Serial Number *</Label>
            <Input
              id="serialNumber"
              name="serialNumber"
              placeholder="Ex: SN123456"
              value={formData.serialNumber}
              onChange={handleChange}
              disabled={isLoading}
            />
          </div>

          {/* Client Name */}
          <div>
            <Label htmlFor="clientName">Nome do Cliente *</Label>
            <Input
              id="clientName"
              name="clientName"
              placeholder="Ex: João Silva"
              value={formData.clientName}
              onChange={handleChange}
              disabled={isLoading}
            />
          </div>

          {/* Client Document */}
          <div>
            <Label htmlFor="clientDocument">Documento do Cliente *</Label>
            <Input
              id="clientDocument"
              name="clientDocument"
              placeholder="Ex: 12345678900"
              value={formData.clientDocument}
              onChange={handleChange}
              disabled={isLoading}
            />
          </div>

          {/* Store */}
          <div>
            {isVendor ? (
              <>
                <Label htmlFor="storeId">Loja Atribuída</Label>
                <div className="flex items-center gap-2 p-3 bg-muted rounded-md border border-border">
                  <span className="text-sm font-medium text-foreground">
                    {userStoreName || "Carregando..."}
                  </span>
                  <span className="text-xs bg-blue-100 text-blue-800 px-2 py-1 rounded">
                    Fixa
                  </span>
                </div>
              </>
            ) : (
              <>
                <Label htmlFor="storeId">Loja *</Label>
                <Select value={formData.storeId} onValueChange={(value) => handleSelectChange("storeId", value)}>
                  <SelectTrigger disabled={isLoading}>
                    <SelectValue placeholder="Selecione uma loja" />
                  </SelectTrigger>
                  <SelectContent>
                    {stores?.map(store => (
                      <SelectItem key={store.id} value={store.id.toString()}>
                        {store.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </>
            )}
          </div>

          {/* Machine */}
          <div>
            <Label htmlFor="machineId">Maquineta Vendida *</Label>
            <Select value={formData.machineId} onValueChange={(value) => handleSelectChange("machineId", value)}>
              <SelectTrigger disabled={isLoading}>
                <SelectValue placeholder="Selecione uma maquineta" />
              </SelectTrigger>
              <SelectContent>
                {machines?.map(machine => (
                  <SelectItem key={machine.id} value={machine.id.toString()}>
                    {machine.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Sale Date */}
          <div>
            <Label htmlFor="saleDate">Data da Venda *</Label>
            <Input
              id="saleDate"
              name="saleDate"
              type="date"
              value={formData.saleDate}
              onChange={handleChange}
              disabled={isLoading}
            />
          </div>

          {/* Sales Origin */}
          <div>
            <Label htmlFor="salesOriginId">Origem da Venda *</Label>
            <Select value={formData.salesOriginId} onValueChange={(value) => handleSelectChange("salesOriginId", value)}>
              <SelectTrigger disabled={isLoading}>
                <SelectValue placeholder="Selecione uma origem" />
              </SelectTrigger>
              <SelectContent>
                {salesOrigins?.map(origin => (
                  <SelectItem key={origin.id} value={origin.id.toString()}>
                    {origin.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Hashtag Origin */}
          <div>
            <Label htmlFor="hashtagOriginId">Origem da Hashtag *</Label>
            <Select value={formData.hashtagOriginId} onValueChange={(value) => handleSelectChange("hashtagOriginId", value)}>
              <SelectTrigger disabled={isLoading}>
                <SelectValue placeholder="Selecione uma hashtag" />
              </SelectTrigger>
              <SelectContent>
                {hashtagOrigins?.map(hashtag => (
                  <SelectItem key={hashtag.id} value={hashtag.id.toString()}>
                    {hashtag.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>

        {/* Delivery Section */}
        <div className="space-y-4">
          <div className="flex items-center gap-2">
            <Checkbox
              id="isDelivery"
              name="isDelivery"
              checked={formData.isDelivery}
              onCheckedChange={(checked) => setFormData(prev => ({ ...prev, isDelivery: checked as boolean }))}
              disabled={isLoading}
            />
            <Label htmlFor="isDelivery" className="cursor-pointer">
              Entrega?
            </Label>
          </div>

          {formData.isDelivery && (
            <div>
              <Label htmlFor="deliveryValue">Valor da Entrega *</Label>
              <Input
                id="deliveryValue"
                name="deliveryValue"
                type="number"
                placeholder="Ex: 50.00"
                step="0.01"
                min="0"
                value={formData.deliveryValue}
                onChange={handleChange}
                disabled={isLoading}
              />
            </div>
          )}
        </div>

        {/* Submit Button */}
        <Button type="submit" disabled={isLoading} className="w-full">
          {isLoading ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Registrando...
            </>
          ) : (
            "Registrar Venda"
          )}
        </Button>
      </form>
    </Card>
  );
}
