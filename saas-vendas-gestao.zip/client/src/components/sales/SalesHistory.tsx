import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import { Trash2, AlertCircle, CheckCircle } from "lucide-react";

export default function SalesHistory() {
  const { data: sales, isLoading, refetch } = trpc.sales.list.useQuery();
  const cancelMutation = trpc.sales.cancel.useMutation();
  const [cancelingId, setCancelingId] = useState<number | null>(null);
  const [cancelReason, setCancelReason] = useState("");

  const handleCancelClick = (saleId: number) => {
    setCancelingId(saleId);
    setCancelReason("");
  };

  const handleConfirmCancel = async (saleId: number) => {
    if (!cancelReason.trim()) {
      toast.error("Por favor, informe o motivo do cancelamento");
      return;
    }

    try {
      await cancelMutation.mutateAsync({
        id: saleId,
        reason: cancelReason,
      });
      toast.success("Venda cancelada com sucesso");
      setCancelingId(null);
      setCancelReason("");
      refetch();
    } catch (error: any) {
      toast.error(error.message || "Erro ao cancelar venda");
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-4">
        <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-primary"></div>
      </div>
    );
  }

  if (!sales || sales.length === 0) {
    return (
      <div className="text-center py-4">
        <p className="text-xs text-muted-foreground">Nenhuma venda registrada</p>
      </div>
    );
  }

  const activeSales = sales.filter(s => !s.isCancelled);
  const totalSales = sales.length;

  return (
    <div className="space-y-2">
      {/* Contador de Vendas */}
      <div className="grid grid-cols-2 gap-2 mb-3">
        <Card className="p-2 bg-green-50 border-green-200">
          <p className="text-xs text-muted-foreground uppercase tracking-wide">Vendas Ativas</p>
          <p className="text-lg font-bold text-green-700">{activeSales.length}</p>
        </Card>
        <Card className="p-2 bg-blue-50 border-blue-200">
          <p className="text-xs text-muted-foreground uppercase tracking-wide">Total</p>
          <p className="text-lg font-bold text-blue-700">{totalSales}</p>
        </Card>
      </div>

      {/* Lista de Vendas */}
      <div className="space-y-1">
        {sales.map((sale: any) => (
          <div
            key={sale.id}
            className={`p-2 rounded border text-xs ${
              sale.isCancelled
                ? "bg-red-50 border-red-200 opacity-60"
                : "bg-white border-gray-200 hover:bg-gray-50"
            }`}
          >
            <div className="flex items-center justify-between gap-2">
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-1 mb-1">
                  <p className="font-semibold text-foreground truncate">
                    {sale.clientName}
                  </p>
                  {sale.isCancelled ? (
                    <AlertCircle className="w-3 h-3 text-red-600 flex-shrink-0" />
                  ) : (
                    <CheckCircle className="w-3 h-3 text-green-600 flex-shrink-0" />
                  )}
                </div>

                <div className="grid grid-cols-2 gap-2 text-xs text-muted-foreground">
                  <div>
                    <p className="text-xs uppercase tracking-wide opacity-70">Serial</p>
                    <p className="font-mono text-xs">{sale.serialNumber}</p>
                  </div>
                  <div>
                    <p className="text-xs uppercase tracking-wide opacity-70">Data</p>
                    <p className="text-xs">{new Date(sale.saleDate).toLocaleDateString("pt-BR")}</p>
                  </div>
                </div>

                {sale.isCancelled && sale.cancellationReason && (
                  <div className="mt-1 p-1 bg-red-100 border border-red-200 rounded text-xs text-red-700">
                    <p className="font-semibold">Motivo:</p>
                    <p className="line-clamp-1">{sale.cancellationReason}</p>
                  </div>
                )}
              </div>

              {!sale.isCancelled && cancelingId !== sale.id && (
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => handleCancelClick(sale.id)}
                  className="text-red-600 hover:text-red-700 hover:bg-red-50 h-6 px-2 flex-shrink-0"
                >
                  <Trash2 className="w-3 h-3" />
                </Button>
              )}

              {cancelingId === sale.id && (
                <div className="w-full max-w-xs ml-2 space-y-1">
                  <Input
                    placeholder="Motivo..."
                    value={cancelReason}
                    onChange={(e) => setCancelReason(e.target.value)}
                    className="text-xs h-7"
                  />
                  <div className="flex gap-1">
                    <Button
                      size="sm"
                      variant="destructive"
                      onClick={() => handleConfirmCancel(sale.id)}
                      disabled={cancelMutation.isPending}
                      className="h-6 text-xs px-2"
                    >
                      OK
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => {
                        setCancelingId(null);
                        setCancelReason("");
                      }}
                      className="h-6 text-xs px-2"
                    >
                      X
                    </Button>
                  </div>
                </div>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
