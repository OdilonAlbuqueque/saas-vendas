import { useAuth } from "@/_core/hooks/useAuth";
import { useLocation } from "wouter";
import { useEffect } from "react";
import { DashboardLayoutSkeleton } from "./DashboardLayoutSkeleton";

interface ProtectedRouteProps {
  children: React.ReactNode;
  requiredRole?: "admin" | "user" | "super_admin" | "any";
}

export function ProtectedRoute({ children, requiredRole = "any" }: ProtectedRouteProps) {
  const { user, loading } = useAuth();
  const [, setLocation] = useLocation();

  useEffect(() => {
    if (loading) return;

    // Se não está autenticado, redirecionar para login
    if (!user) {
      setLocation("/login");
      return;
    }

    // Se requer admin e usuário não é admin, redirecionar para home
    if (requiredRole === "admin" && user.role !== "admin") {
      setLocation("/");
      return;
    }

    // Se requer super_admin e usuário não é super_admin, redirecionar para home
    if (requiredRole === "super_admin" && user.role !== "super_admin") {
      setLocation("/");
      return;
    }
  }, [user, loading, requiredRole, setLocation]);

  if (loading) {
    return <DashboardLayoutSkeleton />;
  }

  if (!user) {
    return null;
  }

  if (requiredRole === "admin" && user.role !== "admin") {
    return null;
  }

  if (requiredRole === "super_admin" && user.role !== "super_admin") {
    return null;
  }

  return <>{children}</>;
}
