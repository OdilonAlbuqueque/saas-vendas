import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import Login from "@/pages/Login";
import ForgotPassword from "@/pages/ForgotPassword";
import ResetPassword from "@/pages/ResetPassword";
import Home from "@/pages/Home";
import Summary from "@/pages/Summary";
import Reports from "@/pages/Reports";
import Admin from "@/pages/Admin";
import AdminPanel from "@/pages/AdminPanel";
import { PayableAccounts } from "@/pages/PayableAccounts";
import { ReceivableAccounts } from "@/pages/ReceivableAccounts";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import { ProtectedRoute } from "./components/ProtectedRoute";

function Router() {
  return (
    <Switch>
      <Route path={"/login"} component={Login} />
      <Route path={"/forgot-password"} component={ForgotPassword} />
      <Route path={"/reset-password"} component={ResetPassword} />
      <Route path={"/"}>
        <ProtectedRoute requiredRole="any">
          <Home />
        </ProtectedRoute>
      </Route>
      <Route path={"/summary"}>
        <ProtectedRoute requiredRole="admin">
          <Summary />
        </ProtectedRoute>
      </Route>
      <Route path={"/reports"}>
        <ProtectedRoute requiredRole="admin">
          <Reports />
        </ProtectedRoute>
      </Route>
      <Route path={"/admin"}>
        <ProtectedRoute requiredRole="admin">
          <Admin />
        </ProtectedRoute>
      </Route>
      <Route path={"/admin-panel"}>
        <ProtectedRoute requiredRole="admin">
          <AdminPanel />
        </ProtectedRoute>
      </Route>
      <Route path={"/payable-accounts"}>
        <ProtectedRoute requiredRole="admin">
          <PayableAccounts />
        </ProtectedRoute>
      </Route>
      <Route path={"/receivable-accounts"}>
        <ProtectedRoute requiredRole="admin">
          <ReceivableAccounts />
        </ProtectedRoute>
      </Route>
      <Route path={"/404"} component={NotFound} />
      {/* Final fallback route */}
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="light">
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
