import { useState } from "react";
import DashboardLayout from "@/components/DashboardLayout";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { toast } from "sonner";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { Plus, Edit2, Trash2, Users, X } from "lucide-react";

export default function AdminPanel() {
  const { user } = useAuth();
  const isOdilon = user?.email === 'odilon.albuquerque.neto@gmail.com';

  const [activeTab, setActiveTab] = useState<"tenants" | "users" | "limits">("tenants");
  const [showCreateForm, setShowCreateForm] = useState(false);
  const [editingTenantId, setEditingTenantId] = useState<string | null>(null);
  const [selectedTenantForLimit, setSelectedTenantForLimit] = useState<string | null>(null);
  const [selectedTenantForUsers, setSelectedTenantForUsers] = useState<string | null>(null);
  const [newLimit, setNewLimit] = useState<number>(5);
  const [formData, setFormData] = useState({
    name: "",
    slug: "",
    email: "",
    phone: "",
  });

  // Se não for Odilon, mostrar acesso negado
  if (!isOdilon) {
    return (
      <DashboardLayout>
        <div className="flex items-center justify-center min-h-[60vh]">
          <Card className="p-8 border border-gray-200 shadow-lg max-w-md">
            <div className="text-center">
              <h1 className="text-2xl font-bold text-gray-900 mb-4">Acesso Negado</h1>
              <p className="text-gray-600 mb-6">Você não tem permissão para acessar o painel administrativo. Apenas o super administrador pode acessar esta área.</p>
              <Button onClick={() => window.location.href = '/'} className="bg-blue-600 hover:bg-blue-700 text-white">
                Voltar para Home
              </Button>
            </div>
          </Card>
        </div>
      </DashboardLayout>
    );
  }

  // Verificar se é admin (super_admin ou admin)
  const { data: userTenants, isLoading: loadingUserTenants } = trpc.tenantUsers.listByUser.useQuery();
  const isSuperAdmin = userTenants?.some(ut => ut.role === "super_admin") ?? true;

  const { data: tenants, isLoading: loadingTenants, refetch: refetchTenants } = trpc.tenants.list.useQuery({
    enabled: isSuperAdmin,
  });

  const { data: selectedTenantLimit, refetch: refetchLimit } = trpc.tenants.getUserLimit.useQuery(
    { tenantId: selectedTenantForLimit || "" },
    { enabled: !!selectedTenantForLimit }
  );

  const { data: tenantUsers, refetch: refetchTenantUsers } = trpc.tenantUsers.listByTenant.useQuery(
    { tenantId: selectedTenantForUsers || "" },
    { enabled: !!selectedTenantForUsers }
  );

  const createTenantMutation = trpc.tenants.create.useMutation();
  const updateTenantMutation = trpc.tenants.update.useMutation();
  const updateLimitMutation = trpc.tenants.updateUserLimit.useMutation();

  const handleCreateTenant = async () => {
    if (!formData.name || !formData.slug || !formData.email) {
      toast.error("Preencha todos os campos obrigatórios");
      return;
    }

    try {
      await createTenantMutation.mutateAsync({
        name: formData.name,
        slug: formData.slug,
        email: formData.email,
        phone: formData.phone || undefined,
      });

      toast.success("Empresa criada com sucesso!");
      setFormData({ name: "", slug: "", email: "", phone: "" });
      setShowCreateForm(false);
      refetchTenants();
    } catch (error: any) {
      toast.error(error.message || "Erro ao criar empresa");
    }
  };

  const handleEditTenant = (tenant: any) => {
    setEditingTenantId(tenant.id);
    setFormData({
      name: tenant.name,
      slug: tenant.slug,
      email: tenant.email,
      phone: tenant.phone || "",
    });
    setShowCreateForm(true);
  };

  const handleSaveEdit = async () => {
    if (!editingTenantId) return;
    if (!formData.name || !formData.slug || !formData.email) {
      toast.error("Preencha todos os campos obrigatórios");
      return;
    }

    try {
      await updateTenantMutation.mutateAsync({
        id: editingTenantId,
        name: formData.name,
        slug: formData.slug,
        email: formData.email,
        phone: formData.phone || undefined,
      });

      toast.success("Empresa atualizada com sucesso!");
      setFormData({ name: "", slug: "", email: "", phone: "" });
      setShowCreateForm(false);
      setEditingTenantId(null);
      refetchTenants();
    } catch (error: any) {
      toast.error(error.message || "Erro ao atualizar empresa");
    }
  };

  const handleUpdateLimit = async () => {
    if (!selectedTenantForLimit) return;

    try {
      await updateLimitMutation.mutateAsync({
        tenantId: selectedTenantForLimit,
        newLimit,
      });

      toast.success("Limite de usuários atualizado com sucesso!");
      refetchLimit();
    } catch (error: any) {
      toast.error(error.message || "Erro ao atualizar limite");
    }
  };

  const handleCancelEdit = () => {
    setEditingTenantId(null);
    setFormData({ name: "", slug: "", email: "", phone: "" });
    setShowCreateForm(false);
  };

  return (
    <DashboardLayout>
      <div className="space-y-8">
        {/* Header */}
        <div>
          <h1 className="text-4xl font-bold text-gray-900 mb-2">Painel Administrativo</h1>
          <p className="text-gray-600">Gerencie empresas, usuários e limites do sistema</p>
        </div>

        {/* Tabs */}
        <div className="flex gap-4 border-b border-gray-200">
          <button
            onClick={() => setActiveTab("tenants")}
            className={`px-4 py-2 font-medium transition-colors ${
              activeTab === "tenants"
                ? "text-blue-600 border-b-2 border-blue-600"
                : "text-gray-600 hover:text-gray-900"
            }`}
          >
            Empresas
          </button>
          <button
            onClick={() => setActiveTab("limits")}
            className={`px-4 py-2 font-medium transition-colors ${
              activeTab === "limits"
                ? "text-blue-600 border-b-2 border-blue-600"
                : "text-gray-600 hover:text-gray-900"
            }`}
          >
            Limites de Usuários
          </button>
          <button
            onClick={() => setActiveTab("users")}
            className={`px-4 py-2 font-medium transition-colors ${
              activeTab === "users"
                ? "text-blue-600 border-b-2 border-blue-600"
                : "text-gray-600 hover:text-gray-900"
            }`}
          >
            Usuários por Empresa
          </button>
        </div>

        {/* Tenants Tab */}
        {activeTab === "tenants" && (
          <div>
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-2xl font-bold text-gray-900">Gerenciar Empresas</h2>
              <Button
                onClick={() => {
                  setEditingTenantId(null);
                  setFormData({ name: "", slug: "", email: "", phone: "" });
                  setShowCreateForm(!showCreateForm);
                }}
                className="bg-blue-600 hover:bg-blue-700 text-white"
              >
                <Plus className="w-4 h-4 mr-2" />
                Nova Empresa
              </Button>
            </div>

            {/* Create/Edit Form */}
            {showCreateForm && (
              <Card className="mb-6 p-6 border border-gray-200 shadow-lg">
                <h3 className="text-lg font-semibold text-gray-900 mb-4">
                  {editingTenantId ? "Editar Empresa" : "Criar Nova Empresa"}
                </h3>
                <div className="grid grid-cols-2 gap-4 mb-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Nome *</label>
                    <Input
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      placeholder="Ex: Empresa XYZ"
                      className="border border-gray-300"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Slug *</label>
                    <Input
                      value={formData.slug}
                      onChange={(e) => setFormData({ ...formData, slug: e.target.value })}
                      placeholder="Ex: empresa-xyz"
                      className="border border-gray-300"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Email *</label>
                    <Input
                      type="email"
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      placeholder="Ex: contato@empresa.com"
                      className="border border-gray-300"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Telefone</label>
                    <Input
                      value={formData.phone}
                      onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                      placeholder="Ex: (11) 9999-9999"
                      className="border border-gray-300"
                    />
                  </div>
                </div>
                <div className="flex gap-2">
                  <Button
                    onClick={editingTenantId ? handleSaveEdit : handleCreateTenant}
                    disabled={createTenantMutation.isPending || updateTenantMutation.isPending}
                    className="bg-blue-600 hover:bg-blue-700 text-white"
                  >
                    {createTenantMutation.isPending || updateTenantMutation.isPending
                      ? "Salvando..."
                      : editingTenantId
                      ? "Salvar Alterações"
                      : "Criar Empresa"}
                  </Button>
                  <Button
                    onClick={handleCancelEdit}
                    variant="outline"
                  >
                    Cancelar
                  </Button>
                </div>
              </Card>
            )}

            {/* Tenants List */}
            {loadingTenants ? (
              <div className="text-center py-8 text-gray-600">Carregando empresas...</div>
            ) : tenants && tenants.length > 0 ? (
              <div className="grid gap-4">
                {tenants.map((tenant) => (
                  <Card key={tenant.id} className="p-6 border border-gray-200 shadow-sm hover:shadow-md transition-shadow">
                    <div className="flex justify-between items-start">
                      <div className="flex-1">
                        <h3 className="text-lg font-semibold text-gray-900">{tenant.name}</h3>
                        <p className="text-sm text-gray-600 mt-1">Slug: {tenant.slug}</p>
                        <p className="text-sm text-gray-600">Email: {tenant.email}</p>
                        {tenant.phone && <p className="text-sm text-gray-600">Telefone: {tenant.phone}</p>}
                        {(tenant as any).schema_name && <p className="text-sm text-gray-500 mt-2">Schema: <code className="bg-gray-100 px-2 py-1 rounded">{(tenant as any).schema_name}</code></p>}
                        <div className="mt-2">
                          <span className={`inline-block px-3 py-1 rounded-full text-xs font-medium ${
                            tenant.status === "active"
                              ? "bg-green-100 text-green-800"
                              : "bg-gray-100 text-gray-800"
                          }`}>
                            {tenant.status === "active" ? "Ativo" : "Inativo"}
                          </span>
                        </div>
                      </div>
                      <div className="flex gap-2">
                        <Button
                          variant="outline"
                          size="sm"
                          className="text-blue-600 hover:text-blue-700 cursor-pointer"
                          onClick={() => {
                            setSelectedTenantForUsers(tenant.id);
                            setActiveTab("users");
                          }}
                          title="Gerenciar usuários"
                        >
                          <Users className="w-4 h-4" />
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          className="text-gray-600 hover:text-gray-700 cursor-pointer"
                          onClick={() => handleEditTenant(tenant)}
                          title="Editar empresa"
                        >
                          <Edit2 className="w-4 h-4" />
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          className="text-red-600 hover:text-red-700 cursor-pointer"
                          title="Deletar empresa"
                          onClick={() => toast.info("Funcionalidade de deletar em desenvolvimento")}
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  </Card>
                ))}
              </div>
            ) : (
              <div className="text-center py-12 text-gray-600">
                <p>Nenhuma empresa cadastrada ainda</p>
              </div>
            )}
          </div>
        )}

        {/* Limits Tab */}
        {activeTab === "limits" && (
          <div>
            <h2 className="text-2xl font-bold text-gray-900 mb-6">Gerenciar Limites de Usuários</h2>
            
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Seleção de Empresa */}
              <Card className="p-6 border border-gray-200 shadow-lg">
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Selecionar Empresa</h3>
                <div className="space-y-2 max-h-96 overflow-y-auto">
                  {tenants?.map((tenant) => (
                    <button
                      key={tenant.id}
                      onClick={() => setSelectedTenantForLimit(tenant.id)}
                      className={`w-full text-left px-4 py-2 rounded-lg transition-colors cursor-pointer ${
                        selectedTenantForLimit === tenant.id
                          ? "bg-blue-100 text-blue-900 border border-blue-300"
                          : "bg-gray-50 text-gray-900 border border-gray-200 hover:bg-gray-100"
                      }`}
                    >
                      {tenant.name}
                    </button>
                  ))}
                </div>
              </Card>

              {/* Limite Atual */}
              {selectedTenantLimit && (
                <Card className="p-6 border border-gray-200 shadow-lg">
                  <h3 className="text-lg font-semibold text-gray-900 mb-4">Limite Atual</h3>
                  <div className="space-y-4">
                    <div>
                      <p className="text-sm text-gray-600 mb-2">Usuários Atuais</p>
                      <p className="text-3xl font-bold text-blue-600">{selectedTenantLimit.currentUsers || 0}</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-600 mb-2">Limite de Usuários</p>
                      <p className="text-3xl font-bold text-gray-900">{selectedTenantLimit.userLimit}</p>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <div
                        className="bg-blue-600 h-2 rounded-full transition-all"
                        style={{
                          width: `${Math.min(
                            ((selectedTenantLimit.currentUsers || 0) / selectedTenantLimit.userLimit) * 100,
                            100
                          )}%`,
                        }}
                      />
                    </div>
                  </div>
                </Card>
              )}

              {/* Atualizar Limite */}
              {selectedTenantLimit && (
                <Card className="p-6 border border-gray-200 shadow-lg">
                  <h3 className="text-lg font-semibold text-gray-900 mb-4">Atualizar Limite</h3>
                  <div className="space-y-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Novo Limite</label>
                      <Input
                        type="number"
                        min="1"
                        max="1000"
                        value={newLimit}
                        onChange={(e) => setNewLimit(Math.max(1, parseInt(e.target.value) || 1))}
                        className="border border-gray-300"
                      />
                    </div>
                    <Button
                      onClick={handleUpdateLimit}
                      disabled={updateLimitMutation.isPending}
                      className="w-full bg-blue-600 hover:bg-blue-700 text-white cursor-pointer"
                    >
                      {updateLimitMutation.isPending ? "Atualizando..." : "Atualizar Limite"}
                    </Button>
                  </div>
                </Card>
              )}
            </div>
          </div>
        )}

        {/* Users Tab */}
        {activeTab === "users" && (
          <div>
            <h2 className="text-2xl font-bold text-gray-900 mb-6">Usuários por Empresa</h2>
            
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Seleção de Empresa */}
              <Card className="p-6 border border-gray-200 shadow-lg">
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Selecionar Empresa</h3>
                <div className="space-y-2 max-h-96 overflow-y-auto">
                  {tenants?.map((tenant) => (
                    <button
                      key={tenant.id}
                      onClick={() => setSelectedTenantForUsers(tenant.id)}
                      className={`w-full text-left px-4 py-2 rounded-lg transition-colors cursor-pointer ${
                        selectedTenantForUsers === tenant.id
                          ? "bg-blue-100 text-blue-900 border border-blue-300"
                          : "bg-gray-50 text-gray-900 border border-gray-200 hover:bg-gray-100"
                      }`}
                    >
                      {tenant.name}
                    </button>
                  ))}
                </div>
              </Card>

              {/* Usuários da Empresa */}
              {selectedTenantForUsers && (
                <Card className="p-6 border border-gray-200 shadow-lg lg:col-span-2">
                  <h3 className="text-lg font-semibold text-gray-900 mb-4">Usuários</h3>
                  {tenantUsers && tenantUsers.length > 0 ? (
                    <div className="space-y-3 max-h-96 overflow-y-auto">
                      {tenantUsers.map((tu) => (
                        <div key={tu.userId} className="p-3 bg-gray-50 rounded-lg border border-gray-200">
                          <p className="text-sm font-medium text-gray-900">ID: {tu.userId}</p>
                          <p className="text-sm text-gray-600">Role: {tu.role}</p>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <p className="text-gray-600">Nenhum usuário nesta empresa</p>
                  )}
                </Card>
              )}
            </div>
          </div>
        )}
      </div>
    </DashboardLayout>
  );
}
