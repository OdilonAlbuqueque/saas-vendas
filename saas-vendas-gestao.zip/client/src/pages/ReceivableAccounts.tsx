import { useState } from 'react';
import DashboardLayout from '@/components/DashboardLayout';
import { trpc } from '@/lib/trpc';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { Trash2, Edit2, Plus } from 'lucide-react';

export function ReceivableAccounts() {
  return (
    <DashboardLayout>
      <ReceivableAccountsContent />
    </DashboardLayout>
  );
}

function ReceivableAccountsContent() {
  const [startDate, setStartDate] = useState<string>(new Date(new Date().getFullYear(), new Date().getMonth(), 1).toISOString().split('T')[0]);
  const [endDate, setEndDate] = useState<string>(new Date().toISOString().split('T')[0]);
  const [category, setCategory] = useState<string>('');
  const [showForm, setShowForm] = useState(false);

  const { data: accounts = [], isLoading, refetch } = trpc.receivableAccounts.list.useQuery({
    startDate: new Date(startDate),
    endDate: new Date(endDate),
    category: category === 'all' ? undefined : category || undefined,
  });

  const createMutation = trpc.receivableAccounts.create.useMutation({
    onSuccess: () => {
      refetch();
      setShowForm(false);
    },
  });

  const deleteMutation = trpc.receivableAccounts.delete.useMutation({
    onSuccess: () => refetch(),
  });

  const handleCreate = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    
    createMutation.mutate({
      contactName: formData.get('contactName') as string,
      description: formData.get('description') as string,
      category: formData.get('category') as string,
      dueDate: new Date(formData.get('dueDate') as string),
      competenceDate: new Date(formData.get('competenceDate') as string),
      value: parseFloat(formData.get('value') as string),
      costCenter: formData.get('costCenter') as string,
      notes: formData.get('notes') as string,
    });
  };

  const totalValue = accounts.reduce((sum, acc) => sum + parseFloat(acc.value), 0);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold text-foreground">Contas a Receber</h1>
        <Button onClick={() => setShowForm(!showForm)} className="bg-green-600 hover:bg-green-700">
          <Plus className="mr-2 h-4 w-4" />
          Nova Conta
        </Button>
      </div>

      {/* Filtros */}
      <Card className="p-6">
        <div className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div>
              <label className="text-sm font-medium text-foreground">Período de vencimento</label>
              <div className="flex gap-2 mt-2">
                <Input
                  type="date"
                  value={startDate}
                  onChange={(e) => setStartDate(e.target.value)}
                  className="text-sm"
                />
                <Input
                  type="date"
                  value={endDate}
                  onChange={(e) => setEndDate(e.target.value)}
                  className="text-sm"
                />
              </div>
            </div>

            <div>
              <label className="text-sm font-medium text-foreground">Categoria</label>
              <Select value={category} onValueChange={setCategory}>
                <SelectTrigger className="mt-2">
                  <SelectValue placeholder="Selecione uma categoria..." />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todas</SelectItem>
                  <SelectItem value="Clientes">Clientes</SelectItem>
                  <SelectItem value="Serviços">Serviços</SelectItem>
                  <SelectItem value="Vendas">Vendas</SelectItem>
                  <SelectItem value="Outros">Outros</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </div>
      </Card>

      {/* Formulário de Nova Conta */}
      {showForm && (
        <Card className="p-6">
          <form onSubmit={handleCreate} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Input
                name="contactName"
                placeholder="Nome do Contato"
                required
                className="text-sm"
              />
              <Input
                name="category"
                placeholder="Categoria"
                required
                className="text-sm"
              />
              <Input
                name="dueDate"
                type="date"
                required
                className="text-sm"
              />
              <Input
                name="competenceDate"
                type="date"
                required
                className="text-sm"
              />
              <Input
                name="value"
                type="number"
                step="0.01"
                placeholder="Valor"
                required
                className="text-sm"
              />
              <Input
                name="costCenter"
                placeholder="Centro de Custo"
                className="text-sm"
              />
            </div>
            <Input
              name="description"
              placeholder="Descrição"
              className="text-sm"
            />
            <Input
              name="notes"
              placeholder="Anotações"
              className="text-sm"
            />
            <div className="flex gap-2">
              <Button type="submit" className="bg-green-600 hover:bg-green-700" disabled={createMutation.isPending}>
                {createMutation.isPending ? 'Salvando...' : 'Salvar'}
              </Button>
              <Button type="button" variant="outline" onClick={() => setShowForm(false)}>
                Cancelar
              </Button>
            </div>
          </form>
        </Card>
      )}

      {/* Tabela de Contas */}
      <Card className="overflow-hidden">
        <Table>
          <TableHeader>
            <TableRow className="bg-muted">
              <TableHead className="text-foreground font-bold">Vencimento</TableHead>
              <TableHead className="text-foreground font-bold">Competência</TableHead>
              <TableHead className="text-foreground font-bold">Nome</TableHead>
              <TableHead className="text-foreground font-bold">Descrição</TableHead>
              <TableHead className="text-foreground font-bold">Categoria</TableHead>
              <TableHead className="text-foreground font-bold">Centro de Custo</TableHead>
              <TableHead className="text-foreground font-bold text-right">Valor em aberto</TableHead>
              <TableHead className="text-foreground font-bold">Ações</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {isLoading ? (
              <TableRow>
                <TableCell colSpan={8} className="text-center py-8 text-muted-foreground">
                  Carregando...
                </TableCell>
              </TableRow>
            ) : accounts.length === 0 ? (
              <TableRow>
                <TableCell colSpan={8} className="text-center py-8 text-muted-foreground">
                  Nenhuma conta a receber encontrada
                </TableCell>
              </TableRow>
            ) : (
              accounts.map((account) => (
                <TableRow key={account.id} className="hover:bg-muted/50">
                  <TableCell className="text-sm">
                    {format(new Date(account.dueDate), 'dd/MM/yyyy', { locale: ptBR })}
                  </TableCell>
                  <TableCell className="text-sm">
                    {format(new Date(account.competenceDate), 'dd/MM/yyyy', { locale: ptBR })}
                  </TableCell>
                  <TableCell className="text-sm font-medium text-cyan-600">{account.contactName}</TableCell>
                  <TableCell className="text-sm">{account.description}</TableCell>
                  <TableCell className="text-sm">{account.category}</TableCell>
                  <TableCell className="text-sm">{account.costCenter}</TableCell>
                  <TableCell className="text-sm text-right font-medium text-green-600">
                    ({account.value})
                  </TableCell>
                  <TableCell className="text-sm">
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => deleteMutation.mutate(account.id)}
                      disabled={deleteMutation.isPending}
                    >
                      <Trash2 className="h-4 w-4 text-red-600" />
                    </Button>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </Card>

      {/* Total */}
      {accounts.length > 0 && (
        <Card className="p-4 bg-muted">
          <div className="flex justify-end">
            <div className="text-right">
              <p className="text-sm text-muted-foreground">Total</p>
              <p className="text-lg font-bold text-green-600">({totalValue.toFixed(2)})</p>
            </div>
          </div>
        </Card>
      )}
    </div>
  );
}
