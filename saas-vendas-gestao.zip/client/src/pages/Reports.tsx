import { useState, useMemo } from "react";
import DashboardLayout from "@/components/DashboardLayout";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { trpc } from "@/lib/trpc";
import { Download, Filter, X, Calendar } from "lucide-react";
import { toast } from "sonner";
import { useAuth } from "@/_core/hooks/useAuth";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

export default function Reports() {
  const { user } = useAuth();
  const { data: sales, isLoading: salesLoading } = trpc.sales.list.useQuery();
  const { data: machines } = trpc.machines.list.useQuery();
  const { data: stores } = trpc.stores.list.useQuery();
  const { data: salesOrigins } = trpc.salesOrigins.list.useQuery();
  const { data: users } = trpc.users.list.useQuery();
  const isDigitalSales = user?.role === "digital_sales";

  const [filters, setFilters] = useState({
    startDate: "",
    endDate: "",
    storeId: "",
    machineId: "",
    originId: "",
    clientName: "",
    clientDocument: "",
    serialNumber: "",
    userId: "",
  });

  const [appliedFilters, setAppliedFilters] = useState({
    startDate: "",
    endDate: "",
    storeId: "",
    machineId: "",
    originId: "",
    clientName: "",
    clientDocument: "",
    serialNumber: "",
    userId: "",
  });

  const applyFilters = () => {
    setAppliedFilters(filters);
    const activeCount = Object.values(filters).filter(v => v !== "").length;
    toast.success(`${activeCount} filtro${activeCount !== 1 ? 's' : ''} aplicado${activeCount !== 1 ? 's' : ''}!`);
  };

  const setPreviousMonth = () => {
    const now = new Date();
    const previousMonth = new Date(now.getFullYear(), now.getMonth() - 1, 1);
    const lastDayOfPreviousMonth = new Date(now.getFullYear(), now.getMonth(), 0);
    
    const startDate = previousMonth.toISOString().split('T')[0];
    const endDate = lastDayOfPreviousMonth.toISOString().split('T')[0];
    
    setFilters({ ...filters, startDate, endDate });
    toast.success(`Filtro de mês anterior aplicado: ${previousMonth.toLocaleString('pt-BR', { month: 'long', year: 'numeric' })}`);
  };

  const filteredSales = useMemo(() => {
    if (!sales) return [];

    return sales.filter(sale => {
      // Excluir vendas canceladas
      if (sale.isCancelled) return false;
      
      if (appliedFilters.startDate && new Date(sale.saleDate) < new Date(appliedFilters.startDate)) return false;
      if (appliedFilters.endDate && new Date(sale.saleDate) > new Date(appliedFilters.endDate)) return false;
      if (appliedFilters.storeId && sale.storeId !== parseInt(appliedFilters.storeId)) return false;
      if (appliedFilters.machineId && sale.machineId !== parseInt(appliedFilters.machineId)) return false;
      if (appliedFilters.originId && sale.salesOriginId !== parseInt(appliedFilters.originId)) return false;
      if (appliedFilters.clientName && !sale.clientName.toLowerCase().includes(appliedFilters.clientName.toLowerCase())) return false;
      if (appliedFilters.clientDocument && !sale.clientDocument.includes(appliedFilters.clientDocument)) return false;
      if (appliedFilters.serialNumber && !sale.serialNumber.toLowerCase().includes(appliedFilters.serialNumber.toLowerCase())) return false;
      if (appliedFilters.userId && sale.userId !== parseInt(appliedFilters.userId)) return false;
      return true;
    });
  }, [sales, appliedFilters]);

  const exportToCSV = () => {
    if (filteredSales.length === 0) {
      toast.error("Nenhum dado para exportar");
      return;
    }

    const headers = [
      "Serial Number",
      "Cliente",
      "Documento",
      "Loja",
      "Maquineta",
      "Vendedor",
      "Data",
      "Entrega",
      "Valor Entrega",
      "Origem",
      "Comissão",
    ];

    const rows = filteredSales.map(sale => {
      const store = stores?.find(s => s.id === sale.storeId);
      const machine = machines?.find(m => m.id === sale.machineId);
      const origin = salesOrigins?.find(o => o.id === sale.salesOriginId);
      const user = users?.find(u => u.id === sale.userId);

      return [
        sale.serialNumber,
        sale.clientName,
        sale.clientDocument,
        store?.name || "",
        machine?.name || "",
        user?.name || "",
        new Date(sale.saleDate).toLocaleDateString("pt-BR"),
        sale.isDelivery ? "Sim" : "Não",
        sale.deliveryValue || "",
        origin?.name || "",
        sale.commissionValue,
      ];
    });

    const csv = [
      headers.join(","),
      ...rows.map(row => row.map(cell => `"${cell}"`).join(",")),
    ].join("\n");

    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
    const link = document.createElement("a");
    const url = URL.createObjectURL(blob);
    link.setAttribute("href", url);
    link.setAttribute("download", `relatorio-vendas-${new Date().toISOString().split('T')[0]}.csv`);
    link.style.visibility = "hidden";
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    toast.success(`${filteredSales.length} vendas exportadas com sucesso!`);
  };

  const exportMutation = trpc.exports.salesToNibo.useMutation();

  const exportToNibo = async () => {
    if (filteredSales.length === 0) {
      toast.error("Nenhum dado para exportar");
      return;
    }

    try {
      const startDate = appliedFilters.startDate ? new Date(appliedFilters.startDate) : undefined;
      const endDate = appliedFilters.endDate ? new Date(appliedFilters.endDate) : undefined;
      const storeId = appliedFilters.storeId ? parseInt(appliedFilters.storeId) : undefined;

      const response = await exportMutation.mutateAsync({
        startDate,
        endDate,
        storeId,
      });

      const binaryString = atob(response.data);
      const bytes = new Uint8Array(binaryString.length);
      for (let i = 0; i < binaryString.length; i++) {
        bytes[i] = binaryString.charCodeAt(i);
      }
      const blob = new Blob([bytes], { type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" });
      const link = document.createElement("a");
      const url = URL.createObjectURL(blob);
      link.setAttribute("href", url);
      link.setAttribute("download", response.filename);
      link.style.visibility = "hidden";
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
      toast.success(`${filteredSales.length} vendas exportadas para Nibo com sucesso!`);
    } catch (error: any) {
      toast.error(error.message || "Erro ao exportar para Nibo");
    }
  };

  const clearFilters = () => {
    setFilters({
      startDate: "",
      endDate: "",
      storeId: "",
      machineId: "",
      originId: "",
      clientName: "",
      clientDocument: "",
      serialNumber: "",
      userId: "",
    });
    setAppliedFilters({
      startDate: "",
      endDate: "",
      storeId: "",
      machineId: "",
      originId: "",
      clientName: "",
      clientDocument: "",
      serialNumber: "",
      userId: "",
    });
  };

  const activeFiltersCount = Object.values(filters).filter(v => v !== "").length;

  // Calculate totals by store
  const totalsByStore = useMemo(() => {
    const storeMap = new Map();
    filteredSales.forEach(sale => {
      const store = stores?.find(s => s.id === sale.storeId);
      if (store) {
        const current = storeMap.get(store.id) || { name: store.name, count: 0, total: 0 };
        current.count += 1;
        current.total += typeof sale.commissionValue === 'string' ? parseFloat(sale.commissionValue) : sale.commissionValue || 0;
        storeMap.set(store.id, current);
      }
    });
    return Array.from(storeMap.values());
  }, [filteredSales, stores]);

  const grandTotal = useMemo(() => {
    return filteredSales.reduce((sum, sale) => sum + (typeof sale.commissionValue === 'string' ? parseFloat(sale.commissionValue) : sale.commissionValue || 0), 0);
  }, [filteredSales]);

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Relatórios</h1>
          <p className="text-muted-foreground mt-2">Visualize e exporte dados de vendas com filtros avançados</p>
        </div>

        {/* Filtros */}
        <Card className="p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <Filter className="w-5 h-5" />
              <h2 className="text-lg font-bold text-foreground">Filtros Avançados</h2>
              {activeFiltersCount > 0 && (
                <span className="ml-2 px-2 py-1 bg-blue-100 text-blue-700 rounded-full text-sm font-medium">
                  {activeFiltersCount} ativo{activeFiltersCount !== 1 ? 's' : ''}
                </span>
              )}
            </div>
            {activeFiltersCount > 0 && (
              <div className="flex gap-2">
                <Button
                  onClick={applyFilters}
                  size="sm"
                  className="gap-2 bg-blue-600 hover:bg-blue-700"
                >
                  <Filter className="w-4 h-4" />
                  Filtrar
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={clearFilters}
                  className="gap-2"
                >
                  <X className="w-4 h-4" />
                  Limpar Filtros
                </Button>
              </div>
            )}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-6 gap-4">
            {/* Botão de Mês Anterior */}
            <div className="space-y-2 flex flex-col justify-end">
              <Button
                onClick={setPreviousMonth}
                variant="outline"
                className="gap-2 h-10"
              >
                <Calendar className="w-4 h-4" />
                Mês Anterior
              </Button>
            </div>

            {/* Filtro de Data */}
            <div className="space-y-2">
              <Label htmlFor="startDate">Data Inicial</Label>
              <Input
                id="startDate"
                type="date"
                value={filters.startDate}
                onChange={(e) => setFilters({ ...filters, startDate: e.target.value })}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="endDate">Data Final</Label>
              <Input
                id="endDate"
                type="date"
                value={filters.endDate}
                onChange={(e) => setFilters({ ...filters, endDate: e.target.value })}
              />
            </div>

            {/* Filtro de Usuário */}
            <div className="space-y-2">
              <Label htmlFor="userId">Vendedor</Label>
              <Select value={filters.userId || "all"} onValueChange={(value) => setFilters({ ...filters, userId: value === "all" ? "" : value })}>
                <SelectTrigger id="userId">
                  <SelectValue placeholder="Todos os vendedores" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todos os vendedores</SelectItem>
                  {users?.filter(u => u.role === "user").map(user => (
                    <SelectItem key={user.id} value={user.id.toString()}>
                      {user.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Filtro de Loja */}
            <div className="space-y-2">
              <Label htmlFor="storeId">Loja</Label>
              <Select value={filters.storeId || "all"} onValueChange={(value) => setFilters({ ...filters, storeId: value === "all" ? "" : value })}>
                <SelectTrigger id="storeId">
                  <SelectValue placeholder="Todas as lojas" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todas as lojas</SelectItem>
                  {stores?.map(store => (
                    <SelectItem key={store.id} value={store.id.toString()}>
                      {store.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Filtro de Maquineta */}
            <div className="space-y-2">
              <Label htmlFor="machineId">Maquineta</Label>
              <Select value={filters.machineId || "all"} onValueChange={(value) => setFilters({ ...filters, machineId: value === "all" ? "" : value })}>
                <SelectTrigger id="machineId">
                  <SelectValue placeholder="Todas as maquinetas" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todas as maquinetas</SelectItem>
                  {machines?.map(machine => (
                    <SelectItem key={machine.id} value={machine.id.toString()}>
                      {machine.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Filtro de Origem */}
            <div className="space-y-2">
              <Label htmlFor="originId">Origem</Label>
              <Select value={filters.originId || "all"} onValueChange={(value) => setFilters({ ...filters, originId: value === "all" ? "" : value })}>
                <SelectTrigger id="originId">
                  <SelectValue placeholder="Todas as origens" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todas as origens</SelectItem>
                  {salesOrigins?.map(origin => (
                    <SelectItem key={origin.id} value={origin.id.toString()}>
                      {origin.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Filtro de Cliente */}
            <div className="space-y-2">
              <Label htmlFor="clientName">Nome do Cliente</Label>
              <Input
                id="clientName"
                type="text"
                placeholder="Buscar cliente"
                value={filters.clientName}
                onChange={(e) => setFilters({ ...filters, clientName: e.target.value })}
              />
            </div>

            {/* Filtro de Documento */}
            <div className="space-y-2">
              <Label htmlFor="clientDocument">Documento</Label>
              <Input
                id="clientDocument"
                type="text"
                placeholder="Buscar documento"
                value={filters.clientDocument}
                onChange={(e) => setFilters({ ...filters, clientDocument: e.target.value })}
              />
            </div>

            {/* Filtro de Serial */}
            <div className="space-y-2">
              <Label htmlFor="serialNumber">Serial Number</Label>
              <Input
                id="serialNumber"
                type="text"
                placeholder="Buscar serial"
                value={filters.serialNumber}
                onChange={(e) => setFilters({ ...filters, serialNumber: e.target.value })}
              />
            </div>
          </div>
        </Card>

        {/* Tabela de Vendas */}
        <Card className="p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-bold text-foreground">Vendas ({filteredSales.length})</h2>
            <div className="flex gap-2">
              <Button onClick={exportToNibo} className="gap-2 bg-green-600 hover:bg-green-700">
                <Download className="w-4 h-4" />
                Exportar para Nibo
              </Button>
              <Button onClick={exportToCSV} className="gap-2">
                <Download className="w-4 h-4" />
                Exportar CSV
              </Button>
            </div>
          </div>

          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Serial</TableHead>
                  <TableHead>Cliente</TableHead>
                  <TableHead>Vendedor</TableHead>
                  <TableHead>Loja</TableHead>
                  <TableHead>Maquineta</TableHead>
                  <TableHead>Data</TableHead>
                  {!isDigitalSales && <TableHead>Comissão</TableHead>}
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredSales.length > 0 ? (
                  filteredSales.map((sale) => {
                    const store = stores?.find(s => s.id === sale.storeId);
                    const machine = machines?.find(m => m.id === sale.machineId);
                    const user = users?.find(u => u.id === sale.userId);
                    const commission = typeof sale.commissionValue === 'string' ? parseFloat(sale.commissionValue) : sale.commissionValue || 0;

                    return (
                      <TableRow key={sale.id}>
                        <TableCell className="font-medium">{sale.serialNumber}</TableCell>
                        <TableCell>{sale.clientName}</TableCell>
                        <TableCell>{user?.name || "-"}</TableCell>
                        <TableCell>{store?.name || "-"}</TableCell>
                        <TableCell>{machine?.name || "-"}</TableCell>
                        <TableCell>{new Date(sale.saleDate).toLocaleDateString("pt-BR")}</TableCell>
                        {!isDigitalSales && (
                          <TableCell className="font-semibold text-green-600">
                            R$ {commission.toLocaleString("pt-BR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                          </TableCell>
                        )}
                      </TableRow>
                    );
                  })
                ) : (
                  <TableRow>
                    <TableCell colSpan={7} className="text-center text-muted-foreground py-8">
                      Nenhuma venda encontrada
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>
        </Card>

        {/* Resumo por Loja */}
        {totalsByStore.length > 0 && !isDigitalSales && (
          <Card className="p-6">
            <h2 className="text-lg font-bold text-foreground mb-4">Resumo por Loja</h2>
            <div className="space-y-2">
              {totalsByStore.map((store) => (
                <div key={store.name} className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
                  <div>
                    <p className="font-medium">{store.name}</p>
                    <p className="text-sm text-muted-foreground">{store.count} venda{store.count !== 1 ? 's' : ''}</p>
                  </div>
                  <p className="font-semibold text-green-600">
                    R$ {store.total.toLocaleString("pt-BR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                  </p>
                </div>
              ))}
              <div className="flex items-center justify-between p-3 bg-blue-50 rounded-lg border border-blue-200 mt-4">
                <p className="font-semibold">Total Geral</p>
                <p className="font-bold text-blue-600 text-lg">
                  R$ {grandTotal.toLocaleString("pt-BR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                </p>
              </div>
            </div>
          </Card>
        )}
      </div>
    </DashboardLayout>
  );
}
