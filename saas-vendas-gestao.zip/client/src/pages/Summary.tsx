import { useState, useEffect } from "react";
import DashboardLayout from "@/components/DashboardLayout";
import { Card } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts";
import { TrendingUp, ShoppingCart, DollarSign, Package } from "lucide-react";

const COLORS = ["#3b82f6", "#10b981", "#f59e0b", "#ef4444", "#8b5cf6", "#ec4899"];

export default function Summary() {
  const { user } = useAuth();
  const { data: sales } = trpc.sales.list.useQuery();
  const { data: machines } = trpc.machines.list.useQuery();
  const { data: stores } = trpc.stores.list.useQuery();
  
  const [selectedStore, setSelectedStore] = useState<string>("");
  const [showCancelled, setShowCancelled] = useState(false);
  const [salesByMachine, setSalesByMachine] = useState<any[]>([]);
  const [commissionByStore, setCommissionByStore] = useState<any[]>([]);
  const [totalSales, setTotalSales] = useState(0);
  const [totalCommission, setTotalCommission] = useState(0);
  const [averageTicket, setAverageTicket] = useState(0);
  const [cancelledCount, setCancelledCount] = useState(0);
  const [cancelledSalesData, setCancelledSalesData] = useState<any[]>([]);

  // Verificar se é vendedor
  const isVendor = user?.role === "user";

  useEffect(() => {
    if (sales && machines && stores) {
      // Get current month and year
      const now = new Date();
      const currentMonth = now.getMonth();
      const currentYear = now.getFullYear();
      
      // Contar vendas canceladas
      const cancelled = sales.filter(s => {
        const saleDate = new Date(s.saleDate);
        const isCurrentMonth = saleDate.getMonth() === currentMonth && saleDate.getFullYear() === currentYear;
        return isCurrentMonth && s.isCancelled;
      });
      setCancelledCount(cancelled.length);

      // Se admin quer ver canceladas, mostrar apenas canceladas
      if (!isVendor && showCancelled) {
        const cancelledSales = sales.filter(s => {
          const saleDate = new Date(s.saleDate);
          const isCurrentMonth = saleDate.getMonth() === currentMonth && saleDate.getFullYear() === currentYear;
          const isSelectedStore = !selectedStore || s.storeId === parseInt(selectedStore);
          return isCurrentMonth && isSelectedStore && s.isCancelled;
        });
        
        const enrichedCancelledSales = cancelledSales.map(sale => {
          const store = stores.find(s => s.id === sale.storeId);
          const machine = machines.find(m => m.id === sale.machineId);
          return {
            ...sale,
            storeName: store?.name || 'N/A',
            machineName: machine?.name || 'N/A',
          };
        });
        
        setTotalSales(cancelledSales.length);
        setTotalCommission(0);
        setAverageTicket(0);
        setSalesByMachine([]);
        setCommissionByStore([]);
        setCancelledSalesData(enrichedCancelledSales);
        return;
      }

      // Para vendedores, filtrar apenas suas vendas
      let filteredSales = sales.filter(s => {
        const saleDate = new Date(s.saleDate);
        const isCurrentMonth = saleDate.getMonth() === currentMonth && saleDate.getFullYear() === currentYear;
        
        // Excluir vendas canceladas
        if (s.isCancelled) return false;
        
        if (isVendor) {
          // Vendedor vê apenas suas vendas
          return isCurrentMonth && s.userId === user?.id;
        } else {
          // Admin vê todas as vendas ou filtra por loja se selecionada
          const isSelectedStore = !selectedStore || s.storeId === parseInt(selectedStore);
          return isCurrentMonth && isSelectedStore;
        }
      });

      // Calculate totals
      setTotalSales(filteredSales.length);
      const commission = filteredSales.reduce((sum, sale) => sum + (typeof sale.commissionValue === 'string' ? parseFloat(sale.commissionValue) : sale.commissionValue || 0), 0);
      setTotalCommission(commission);
      
      // Calculate average ticket (commission value = sale value for this company)
      const avgTicket = filteredSales.length > 0 ? commission / filteredSales.length : 0;
      setAverageTicket(avgTicket);

      // Group by machine - show count and total commission
      const machineMap = new Map();
      filteredSales.forEach(sale => {
        const machine = machines.find(m => m.id === sale.machineId);
        if (machine) {
          const key = machine.name;
          const current = machineMap.get(key) || { name: key, count: 0, commission: 0 };
          current.count += 1;
          current.commission += typeof sale.commissionValue === 'string' ? parseFloat(sale.commissionValue) : sale.commissionValue || 0;
          machineMap.set(key, current);
        }
      });
      setSalesByMachine(Array.from(machineMap.values()));

      // Group by store - show total commission
      const storeMap = new Map();
      filteredSales.forEach(sale => {
        const store = stores.find(s => s.id === sale.storeId);
        if (store) {
          const key = store.name;
          const current = storeMap.get(key) || { name: key, commission: 0, count: 0 };
          current.commission += typeof sale.commissionValue === 'string' ? parseFloat(sale.commissionValue) : sale.commissionValue || 0;
          current.count += 1;
          storeMap.set(key, current);
        }
      });
      setCommissionByStore(Array.from(storeMap.values()));
      setCancelledSalesData([]);
    }
  }, [sales, machines, stores, selectedStore, user, isVendor, showCancelled]);

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-foreground">
              Resumo de Vendas - {new Date().toLocaleString('pt-BR', { month: 'long', year: 'numeric' }).charAt(0).toUpperCase() + new Date().toLocaleString('pt-BR', { month: 'long', year: 'numeric' }).slice(1)}
            </h1>
            <p className="text-muted-foreground mt-2" style={{paddingLeft: '20px'}}>
              {isVendor ? "Suas vendas do mês atual" : "Visão geral do desempenho de vendas do mês atual"}
            </p>
          </div>
          
          {/* Filtro de Loja - Apenas para Admin */}
          {!isVendor && (
            <div className="flex gap-4">
              <div className="w-48">
              <Label htmlFor="store-filter" className="text-sm font-medium mb-2 block">Filtrar por Loja</Label>
              <Select value={selectedStore || "all"} onValueChange={(value) => setSelectedStore(value === "all" ? "" : value)}>
                <SelectTrigger id="store-filter">
                  <SelectValue placeholder="Todas as lojas" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todas as lojas</SelectItem>
                  {stores?.map(store => (
                    <SelectItem key={store.id} value={store.id.toString()}>
                      {store.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              </div>
              <div className="w-48">
                <Label htmlFor="cancelled-filter" className="text-sm font-medium mb-2 block">Ver Canceladas</Label>
                <Select value={showCancelled ? "cancelled" : "active"} onValueChange={(value) => setShowCancelled(value === "cancelled")}>
                  <SelectTrigger id="cancelled-filter">
                    <SelectValue placeholder="Vendas Ativas" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="active">Vendas Ativas ({totalSales})</SelectItem>
                    <SelectItem value="cancelled">Vendas Canceladas ({cancelledCount})</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          )}
        </div>

        {/* KPI Cards */}
        <div className={`grid gap-4 ${isVendor ? 'grid-cols-1 md:grid-cols-2' : 'grid-cols-1 md:grid-cols-2 lg:grid-cols-4'}`}>
          <Card className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Total de Vendas</p>
                <p className="text-3xl font-bold text-foreground mt-2">{totalSales}</p>
              </div>
              <ShoppingCart className="h-8 w-8 text-blue-500 opacity-50" />
            </div>
          </Card>

          {/* Mostrar valores apenas para Admin */}
          {!isVendor && (
            <>
              <Card className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Faturamento Total</p>
                    <p className="text-3xl font-bold text-foreground mt-2">R$ {totalCommission.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</p>
                  </div>
                  <DollarSign className="h-8 w-8 text-green-500 opacity-50" />
                </div>
              </Card>

              <Card className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Ticket Médio</p>
                    <p className="text-3xl font-bold text-foreground mt-2">R$ {averageTicket.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</p>
                  </div>
                  <TrendingUp className="h-8 w-8 text-purple-500 opacity-50" />
                </div>
              </Card>

              <Card className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Maquinetas Vendidas</p>
                    <p className="text-3xl font-bold text-foreground mt-2">{salesByMachine.length}</p>
                  </div>
                  <Package className="h-8 w-8 text-orange-500 opacity-50" />
                </div>
              </Card>
            </>
          )}
        </div>

        {/* Charts - Apenas para Admin */}
        {!isVendor && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Faturamento por Maquineta */}
            <Card className="p-6">
              <h2 className="text-lg font-semibold mb-4">Faturamento por Maquineta</h2>
              {salesByMachine.length > 0 ? (
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={salesByMachine}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" angle={-45} textAnchor="end" height={100} />
                    <YAxis />
                    <Tooltip 
                      formatter={(value) => `R$ ${Number(value).toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`}
                      labelFormatter={(label) => `${label}`}
                    />
                    <Legend />
                    <Bar dataKey="commission" fill="#3b82f6" name="Faturamento (R$)" />
                  </BarChart>
                </ResponsiveContainer>
              ) : (
                <div className="h-64 flex items-center justify-center text-muted-foreground">
                  Nenhum dado disponível
                </div>
              )}
            </Card>

            {/* Faturamento por Loja */}
            <Card className="p-6">
              <h2 className="text-lg font-semibold mb-4">Faturamento por Loja</h2>
              {commissionByStore.length > 0 ? (
                <div className="space-y-3">
                  {commissionByStore.map((store, index) => (
                    <div key={index} className="flex items-center justify-between p-3 bg-muted rounded-lg">
                      <div className="flex items-center gap-3">
                        <div 
                          className="w-3 h-3 rounded-full" 
                          style={{ backgroundColor: COLORS[index % COLORS.length] }}
                        />
                        <div>
                          <p className="font-medium text-foreground">{store.name}</p>
                          <p className="text-sm text-muted-foreground">{store.count} venda{store.count !== 1 ? 's' : ''}</p>
                        </div>
                      </div>
                      <p className="text-lg font-bold text-green-600">R$ {store.commission.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</p>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="h-64 flex items-center justify-center text-muted-foreground">
                  Nenhum dado disponível
                </div>
              )}
            </Card>
          </div>
        )}

        {/* Tabela de Vendas Canceladas - Apenas para Admin */}
        {!isVendor && showCancelled && cancelledSalesData.length > 0 && (
          <Card className="p-6">
            <h2 className="text-lg font-semibold mb-4">Vendas Canceladas do Mês</h2>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-red-50 border-b border-red-200">
                  <tr>
                    <th className="px-4 py-3 text-left text-sm font-semibold text-red-900">Serial</th>
                    <th className="px-4 py-3 text-left text-sm font-semibold text-red-900">Cliente</th>
                    <th className="px-4 py-3 text-left text-sm font-semibold text-red-900">Loja</th>
                    <th className="px-4 py-3 text-left text-sm font-semibold text-red-900">Maquineta</th>
                    <th className="px-4 py-3 text-left text-sm font-semibold text-red-900">Vendedor</th>
                    <th className="px-4 py-3 text-left text-sm font-semibold text-red-900">Motivo</th>
                    <th className="px-4 py-3 text-left text-sm font-semibold text-red-900">Data</th>
                  </tr>
                </thead>
                <tbody className="divide-y">
                  {cancelledSalesData.map(sale => (
                    <tr key={sale.id} className="hover:bg-red-50/50 transition-colors">
                      <td className="px-4 py-3 text-sm text-foreground">{sale.serialNumber}</td>
                      <td className="px-4 py-3 text-sm text-foreground">{sale.clientName}</td>
                      <td className="px-4 py-3 text-sm text-foreground">{sale.storeName}</td>
                      <td className="px-4 py-3 text-sm text-foreground">{sale.machineName}</td>
                      <td className="px-4 py-3 text-sm text-foreground">{sale.userName || '-'}</td>
                      <td className="px-4 py-3 text-sm text-red-700 font-medium">{sale.cancellationReason || '-'}</td>
                      <td className="px-4 py-3 text-sm text-foreground">{new Date(sale.saleDate).toLocaleDateString('pt-BR')}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </Card>
        )}

        {/* Tabela de Vendas do Mês para Vendedores */}
        {isVendor && (
          <Card className="p-6">
            <h2 className="text-lg font-semibold mb-4">Suas Vendas do Mês</h2>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-muted border-b">
                  <tr>
                    <th className="px-4 py-3 text-left text-sm font-semibold text-foreground">Serial Number</th>
                    <th className="px-4 py-3 text-left text-sm font-semibold text-foreground">Cliente</th>
                    <th className="px-4 py-3 text-left text-sm font-semibold text-foreground">Maquineta</th>
                    <th className="px-4 py-3 text-left text-sm font-semibold text-foreground">Data</th>
                  </tr>
                </thead>
                <tbody className="divide-y">
                  {sales && sales.filter(s => {
                    const saleDate = new Date(s.saleDate);
                    const now = new Date();
                    return saleDate.getMonth() === now.getMonth() && 
                           saleDate.getFullYear() === now.getFullYear() &&
                           s.userId === user?.id;
                  }).length > 0 ? (
                    sales.filter(s => {
                      const saleDate = new Date(s.saleDate);
                      const now = new Date();
                      return saleDate.getMonth() === now.getMonth() && 
                             saleDate.getFullYear() === now.getFullYear() &&
                             s.userId === user?.id;
                    }).map(sale => {
                      const machine = machines?.find(m => m.id === sale.machineId);
                      return (
                        <tr key={sale.id} className="hover:bg-muted/50 transition-colors">
                          <td className="px-4 py-3 text-sm text-foreground">{sale.serialNumber}</td>
                          <td className="px-4 py-3 text-sm text-foreground">{sale.clientName}</td>
                          <td className="px-4 py-3 text-sm text-foreground">{machine?.name || "-"}</td>
                          <td className="px-4 py-3 text-sm text-foreground">{new Date(sale.saleDate).toLocaleDateString("pt-BR")}</td>
                        </tr>
                      );
                    })
                  ) : (
                    <tr>
                      <td colSpan={4} className="px-4 py-8 text-center text-muted-foreground">
                        Nenhuma venda registrada neste mês
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </Card>
        )}
      </div>
    </DashboardLayout>
  );
}
