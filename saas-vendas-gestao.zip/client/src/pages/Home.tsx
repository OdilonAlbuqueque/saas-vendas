import { useState, useEffect } from "react";
import DashboardLayout from "@/components/DashboardLayout";
import SalesForm from "@/components/sales/SalesForm";
import SalesHistory from "@/components/sales/SalesHistory";
import { useAuth } from "@/_core/hooks/useAuth";

export default function Home() {
  const { user, loading } = useAuth();
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
  }, []);

  if (!mounted || loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 to-indigo-100">
        <div className="text-center">
          <h1 className="text-3xl font-bold text-foreground mb-4">Acesso Restrito</h1>
          <p className="text-muted-foreground mb-6">Você precisa estar autenticado para acessar o sistema</p>
          <a href="/login" className="inline-block px-6 py-2 bg-primary text-primary-foreground rounded-lg hover:opacity-90">
            Ir para Login
          </a>
        </div>
      </div>
    );
  }

  return (
    <DashboardLayout>
      <div className="space-y-8">
        <div>
          <h1 className="text-3xl font-bold text-foreground" style={{paddingLeft: '18px'}}>Registro de Vendas</h1>
          <p className="text-muted-foreground mt-2">Registre uma nova venda de maquineta</p>
        </div>
        
        <SalesForm />

        <div className="border-t pt-8">
          <SalesHistory />
        </div>
      </div>
    </DashboardLayout>
  );
}
