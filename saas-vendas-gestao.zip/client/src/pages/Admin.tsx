import { useState } from "react";
import DashboardLayout from "@/components/DashboardLayout";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { toast } from "sonner";
import { trpc } from "@/lib/trpc";
import { Plus, Trash2, Edit2, X, Check } from "lucide-react";
import { UsersManagement } from "@/components/admin/UsersManagement";

export default function Admin() {
  const [newStore, setNewStore] = useState({ name: "", location: "" });
  const [newMachine, setNewMachine] = useState({ name: "", commissionValue: "" });
  const [newOrigin, setNewOrigin] = useState("");
  const [newHashtag, setNewHashtag] = useState("");

  const [editingStore, setEditingStore] = useState<any>(null);
  const [editingMachine, setEditingMachine] = useState<any>(null);
  const [editingOrigin, setEditingOrigin] = useState<any>(null);
  const [editingHashtag, setEditingHashtag] = useState<any>(null);

  // Queries
  const { data: stores, refetch: refetchStores } = trpc.stores.list.useQuery();
  const { data: machines, refetch: refetchMachines } = trpc.machines.list.useQuery();
  const { data: salesOrigins, refetch: refetchOrigins } = trpc.salesOrigins.list.useQuery();
  const { data: hashtagOrigins, refetch: refetchHashtags } = trpc.hashtagOrigins.list.useQuery();

  // Mutations
  const createStoreMutation = trpc.stores.create.useMutation();
  const createMachineMutation = trpc.machines.create.useMutation();
  const createOriginMutation = trpc.salesOrigins.create.useMutation();
  const createHashtagMutation = trpc.hashtagOrigins.create.useMutation();

  const deleteStoreMutation = trpc.stores.delete.useMutation();
  const deleteMachineMutation = trpc.machines.delete.useMutation();
  const deleteOriginMutation = trpc.salesOrigins.delete.useMutation();
  const deleteHashtagMutation = trpc.hashtagOrigins.delete.useMutation();

  // Store Handlers
  const handleAddStore = async () => {
    if (!newStore.name.trim()) {
      toast.error("Nome da loja é obrigatório");
      return;
    }

    try {
      await createStoreMutation.mutateAsync({
        name: newStore.name,
        location: newStore.location,
      });
      toast.success("Loja criada com sucesso!");
      setNewStore({ name: "", location: "" });
      refetchStores();
    } catch (error: any) {
      toast.error(error.message || "Erro ao criar loja");
    }
  };

  const handleDeleteStore = async (id: number) => {
    if (confirm("Tem certeza que deseja excluir esta loja?")) {
      try {
        await deleteStoreMutation.mutateAsync({ id });
        toast.success("Loja excluída com sucesso!");
        refetchStores();
      } catch (error: any) {
        toast.error(error.message || "Erro ao excluir loja");
      }
    }
  };

  // Machine Handlers
  const handleAddMachine = async () => {
    if (!newMachine.name.trim() || !newMachine.commissionValue) {
      toast.error("Nome e valor da comissão são obrigatórios");
      return;
    }

    try {
      await createMachineMutation.mutateAsync({
        name: newMachine.name,
        commissionValue: parseFloat(newMachine.commissionValue),
      });
      toast.success("Maquineta criada com sucesso!");
      setNewMachine({ name: "", commissionValue: "" });
      refetchMachines();
    } catch (error: any) {
      toast.error(error.message || "Erro ao criar maquineta");
    }
  };

  const handleEditMachine = async (id: number, name: string, commissionValue: number) => {
    if (!name.trim()) {
      toast.error("Nome da maquineta eh obrigatorio");
      return;
    }
    try {
      await createMachineMutation.mutateAsync({
        name,
        commissionValue,
      });
      toast.success("Maquineta atualizada com sucesso!");
      setEditingMachine(null);
      refetchMachines();
    } catch (error: any) {
      toast.error(error.message || "Erro ao atualizar maquineta");
    }
  };

  const handleDeleteMachine = async (id: number) => {
    if (confirm("Tem certeza que deseja excluir esta maquineta?")) {
      try {
        await deleteMachineMutation.mutateAsync({ id });
        toast.success("Maquineta excluída com sucesso!");
        refetchMachines();
      } catch (error: any) {
        toast.error(error.message || "Erro ao excluir maquineta");
      }
    }
  };

  // Origin Handlers
  const handleAddOrigin = async () => {
    if (!newOrigin.trim()) {
      toast.error("Nome da origem é obrigatório");
      return;
    }

    try {
      await createOriginMutation.mutateAsync({ name: newOrigin });
      toast.success("Origem criada com sucesso!");
      setNewOrigin("");
      refetchOrigins();
    } catch (error: any) {
      toast.error(error.message || "Erro ao criar origem");
    }
  };

  const handleDeleteOrigin = async (id: number) => {
    if (confirm("Tem certeza que deseja excluir esta origem?")) {
      try {
        await deleteOriginMutation.mutateAsync({ id });
        toast.success("Origem excluída com sucesso!");
        refetchOrigins();
      } catch (error: any) {
        toast.error(error.message || "Erro ao excluir origem");
      }
    }
  };

  // Hashtag Handlers
  const handleAddHashtag = async () => {
    if (!newHashtag.trim()) {
      toast.error("Nome da hashtag é obrigatório");
      return;
    }

    try {
      await createHashtagMutation.mutateAsync({ name: newHashtag });
      toast.success("Hashtag criada com sucesso!");
      setNewHashtag("");
      refetchHashtags();
    } catch (error: any) {
      toast.error(error.message || "Erro ao criar hashtag");
    }
  };

  const handleDeleteHashtag = async (id: number) => {
    if (confirm("Tem certeza que deseja excluir esta hashtag?")) {
      try {
        await deleteHashtagMutation.mutateAsync({ id });
        toast.success("Hashtag excluída com sucesso!");
        refetchHashtags();
      } catch (error: any) {
        toast.error(error.message || "Erro ao excluir hashtag");
      }
    }
  };

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Painel Administrativo</h1>
          <p className="text-muted-foreground mt-2">Gerencie os cadastros do sistema</p>
        </div>

        <Tabs defaultValue="stores" className="w-full">
          <TabsList className="grid w-full grid-cols-5">
            <TabsTrigger value="users">Usuários</TabsTrigger>
            <TabsTrigger value="stores">Lojas</TabsTrigger>
            <TabsTrigger value="machines">Maquinetas</TabsTrigger>
            <TabsTrigger value="origins">Origens</TabsTrigger>
            <TabsTrigger value="hashtags">Hashtags</TabsTrigger>
          </TabsList>

          {/* Users Tab */}
          <TabsContent value="users" className="space-y-4">
            <UsersManagement />
          </TabsContent>

          {/* Stores Tab */}
          <TabsContent value="stores" className="space-y-4">
            <Card className="p-6">
              <h2 className="text-lg font-bold text-foreground mb-4">Adicionar Loja</h2>
              <div className="space-y-4">
                <div>
                  <Label htmlFor="storeName">Nome da Loja</Label>
                  <Input
                    id="storeName"
                    placeholder="Ex: Loja Centro"
                    value={newStore.name}
                    onChange={(e) => setNewStore(prev => ({ ...prev, name: e.target.value }))}
                  />
                </div>
                <div>
                  <Label htmlFor="storeLocation">Localização</Label>
                  <Input
                    id="storeLocation"
                    placeholder="Ex: Av. Principal, 123"
                    value={newStore.location}
                    onChange={(e) => setNewStore(prev => ({ ...prev, location: e.target.value }))}
                  />
                </div>
                <Button onClick={handleAddStore} className="gap-2">
                  <Plus className="h-4 w-4" />
                  Adicionar Loja
                </Button>
              </div>
            </Card>

            <Card className="p-6">
              <h2 className="text-lg font-bold text-foreground mb-4">Lojas Cadastradas</h2>
              <div className="space-y-2">
                {stores?.map(store => (
                  <div key={store.id} className="flex items-center justify-between p-3 bg-muted/50 rounded-lg hover:bg-muted transition">
                    <div className="flex-1">
                      <p className="font-medium">{store.name}</p>
                      {store.location && <p className="text-sm text-muted-foreground">{store.location}</p>}
                    </div>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handleDeleteStore(store.id)}
                      className="text-red-500 hover:text-red-700 hover:bg-red-50"
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                ))}
                {!stores || stores.length === 0 && (
                  <p className="text-center text-muted-foreground py-4">Nenhuma loja cadastrada</p>
                )}
              </div>
            </Card>
          </TabsContent>

          {/* Machines Tab */}
          <TabsContent value="machines" className="space-y-4">
            <Card className="p-6">
              <h2 className="text-lg font-bold text-foreground mb-4">Adicionar Maquineta</h2>
              <div className="space-y-4">
                <div>
                  <Label htmlFor="machineName">Nome da Maquineta</Label>
                  <Input
                    id="machineName"
                    placeholder="Ex: Smart Ton Black"
                    value={newMachine.name}
                    onChange={(e) => setNewMachine(prev => ({ ...prev, name: e.target.value }))}
                  />
                </div>
                <div>
                  <Label htmlFor="commissionValue">Valor da Comissão</Label>
                  <Input
                    id="commissionValue"
                    type="number"
                    placeholder="Ex: 270.00"
                    step="0.01"
                    min="0"
                    value={newMachine.commissionValue}
                    onChange={(e) => setNewMachine(prev => ({ ...prev, commissionValue: e.target.value }))}
                  />
                </div>
                <Button onClick={handleAddMachine} className="gap-2">
                  <Plus className="h-4 w-4" />
                  Adicionar Maquineta
                </Button>
              </div>
            </Card>

            <Card className="p-6">
              <h2 className="text-lg font-bold text-foreground mb-4">Maquinetas Cadastradas</h2>
              <div className="space-y-2">
                {machines?.map(machine => (
                  <div key={machine.id} className="flex items-center justify-between p-3 bg-muted/50 rounded-lg hover:bg-muted transition">
                    {editingMachine?.id === machine.id ? (
                      <div className="flex-1 space-y-2">
                        <Input
                          placeholder="Nome da maquineta"
                          value={editingMachine.name}
                          onChange={(e) => setEditingMachine((prev: any) => ({ ...prev, name: e.target.value }))}
                        />
                        <Input
                          type="number"
                          placeholder="Valor da comissão"
                          step="0.01"
                          min="0"
                          value={editingMachine.commissionValue}
                          onChange={(e) => setEditingMachine((prev: any) => ({ ...prev, commissionValue: e.target.value }))}
                        />
                      </div>
                    ) : (
                      <div className="flex-1">
                        <p className="font-medium">{machine.name}</p>
                        <p className="text-sm text-muted-foreground">Comissão: R$ {parseFloat(machine.commissionValue || "0").toFixed(2)}</p>
                      </div>
                    )}
                    <div className="flex gap-2">
                      {editingMachine?.id === machine.id ? (
                        <>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleEditMachine(editingMachine.id, editingMachine.name, parseFloat(editingMachine.commissionValue))}
                            className="text-green-500 hover:text-green-700 hover:bg-green-50"
                          >
                            <Check className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => setEditingMachine(null)}
                            className="text-gray-500 hover:text-gray-700 hover:bg-gray-50"
                          >
                            <X className="h-4 w-4" />
                          </Button>
                        </>
                      ) : (
                        <>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => setEditingMachine({ ...machine })}
                            className="text-blue-500 hover:text-blue-700 hover:bg-blue-50"
                          >
                            <Edit2 className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleDeleteMachine(machine.id)}
                            className="text-red-500 hover:text-red-700 hover:bg-red-50"
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </>
                      )}
                    </div>
                  </div>
                ))}
                {!machines || machines.length === 0 && (
                  <p className="text-center text-muted-foreground py-4">Nenhuma maquineta cadastrada</p>
                )}
              </div>
            </Card>
          </TabsContent>

          {/* Origins Tab */}
          <TabsContent value="origins" className="space-y-4">
            <Card className="p-6">
              <h2 className="text-lg font-bold text-foreground mb-4">Adicionar Origem de Venda</h2>
              <div className="space-y-4">
                <div>
                  <Label htmlFor="originName">Nome da Origem</Label>
                  <Input
                    id="originName"
                    placeholder="Ex: Telefone"
                    value={newOrigin}
                    onChange={(e) => setNewOrigin(e.target.value)}
                  />
                </div>
                <Button onClick={handleAddOrigin} className="gap-2">
                  <Plus className="h-4 w-4" />
                  Adicionar Origem
                </Button>
              </div>
            </Card>

            <Card className="p-6">
              <h2 className="text-lg font-bold text-foreground mb-4">Origens Cadastradas</h2>
              <div className="space-y-2">
                {salesOrigins?.map(origin => (
                  <div key={origin.id} className="flex items-center justify-between p-3 bg-muted/50 rounded-lg hover:bg-muted transition">
                    <p className="font-medium">{origin.name}</p>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handleDeleteOrigin(origin.id)}
                      className="text-red-500 hover:text-red-700 hover:bg-red-50"
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                ))}
                {!salesOrigins || salesOrigins.length === 0 && (
                  <p className="text-center text-muted-foreground py-4">Nenhuma origem cadastrada</p>
                )}
              </div>
            </Card>
          </TabsContent>

          {/* Hashtags Tab */}
          <TabsContent value="hashtags" className="space-y-4">
            <Card className="p-6">
              <h2 className="text-lg font-bold text-foreground mb-4">Adicionar Origem de Hashtag</h2>
              <div className="space-y-4">
                <div>
                  <Label htmlFor="hashtagName">Nome da Hashtag</Label>
                  <Input
                    id="hashtagName"
                    placeholder="Ex: #Instagram"
                    value={newHashtag}
                    onChange={(e) => setNewHashtag(e.target.value)}
                  />
                </div>
                <Button onClick={handleAddHashtag} className="gap-2">
                  <Plus className="h-4 w-4" />
                  Adicionar Hashtag
                </Button>
              </div>
            </Card>

            <Card className="p-6">
              <h2 className="text-lg font-bold text-foreground mb-4">Hashtags Cadastradas</h2>
              <div className="space-y-2">
                {hashtagOrigins?.map(hashtag => (
                  <div key={hashtag.id} className="flex items-center justify-between p-3 bg-muted/50 rounded-lg hover:bg-muted transition">
                    <p className="font-medium">{hashtag.name}</p>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handleDeleteHashtag(hashtag.id)}
                      className="text-red-500 hover:text-red-700 hover:bg-red-50"
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                ))}
                {!hashtagOrigins || hashtagOrigins.length === 0 && (
                  <p className="text-center text-muted-foreground py-4">Nenhuma hashtag cadastrada</p>
                )}
              </div>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </DashboardLayout>
  );
}
