import { describe, it, expect, beforeAll, afterAll } from 'vitest';
import * as db from './db';

describe('Tenants - Multi-schema', () => {
  let createdTenantId: string | null = null;

  beforeAll(async () => {
    // Aguardar conexão com banco de dados
    const database = await db.getDb();
    expect(database).toBeDefined();
  });

  it('should create a tenant with a unique schema_name', async () => {
    const tenantData = {
      name: 'Test Company',
      slug: 'test-company',
      email: 'test@company.com',
      phone: '1234567890',
    };

    const tenant = await db.createTenant(tenantData);
    
    expect(tenant).toBeDefined();
    expect(tenant?.id).toBeDefined();
    expect(tenant?.name).toBe(tenantData.name);
    expect(tenant?.slug).toBe(tenantData.slug);
    expect(tenant?.schema_name).toBeDefined();
    expect(tenant?.schema_name).toMatch(/^schema_test_company_\d+$/);
    
    createdTenantId = tenant?.id || null;
  });

  it('should retrieve created tenant with schema_name', async () => {
    if (!createdTenantId) {
      expect.fail('Tenant ID not set from previous test');
    }

    const tenant = await db.getTenant(createdTenantId);
    
    expect(tenant).toBeDefined();
    expect(tenant?.schema_name).toBeDefined();
    expect(tenant?.schema_name).toMatch(/^schema_test_company_\d+$/);
  });

  it('should list tenants including schema_name', async () => {
    const tenants = await db.listTenants();
    
    expect(Array.isArray(tenants)).toBe(true);
    expect(tenants.length).toBeGreaterThan(0);
    
    const testTenant = tenants.find(t => t.slug === 'test-company');
    expect(testTenant).toBeDefined();
    expect(testTenant?.schema_name).toBeDefined();
  });

  afterAll(async () => {
    // Cleanup: Delete test tenant if created
    if (createdTenantId) {
      // Note: In production, you might want to also drop the schema
      // For now, we'll just leave it as the test database will be cleaned up
      console.log(`Test tenant created with ID: ${createdTenantId}`);
    }
  });
});
