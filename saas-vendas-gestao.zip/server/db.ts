import { eq, and, sql } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { 
  InsertUser, users, 
  InsertCompany, companies,
  InsertStore, stores,
  InsertMachine, machines,
  InsertSalesOrigin, salesOrigins,
  InsertHashtagOrigin, hashtagOrigins,
  InsertSale, sales,
  InsertPayableAccount, payableAccounts,
  InsertReceivableAccount, receivableAccounts,
  User, Company, Store, Machine, SalesOrigin, HashtagOrigin, Sale, PayableAccount, ReceivableAccount,
  tenants, tenantUsers, tenantRoles,
  Tenant, TenantUser, TenantRole
} from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

// ==================== AUTENTICAÇÃO ====================

export async function loginUser(email: string, password: string): Promise<User | null> {
  const db = await getDb();
  if (!db) return null;

  const result = await db
    .select()
    .from(users)
    .where(and(eq(users.email, email), eq(users.isActive, true)))
    .limit(1);

  if (result.length === 0) return null;
  
  const user = result[0];
  
  // Validar senha com bcrypt
  const bcrypt = await import('bcryptjs');
  const isPasswordValid = await bcrypt.compare(password, user.password);
  
  if (!isPasswordValid) return null;
  
  return user;
}

export async function getUserById(id: number): Promise<User | null> {
  const db = await getDb();
  if (!db) return null;

  const result = await db.select().from(users).where(eq(users.id, id)).limit(1);
  return result.length > 0 ? result[0] : null;
}

export async function getUserByEmail(email: string): Promise<User | null> {
  const db = await getDb();
  if (!db) return null;

  const result = await db.select().from(users).where(eq(users.email, email)).limit(1);
  return result.length > 0 ? result[0] : null;
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
      companyId: user.companyId || 1,
      password: user.password || "",
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

// ==================== LOJAS ====================

export async function getStoresByCompany(companyId: number): Promise<Store[]> {
  const db = await getDb();
  if (!db) return [];

  return db.select().from(stores).where(and(eq(stores.companyId, companyId), eq(stores.isActive, true)));
}

export async function getStoreById(id: number, companyId: number): Promise<Store | null> {
  const db = await getDb();
  if (!db) return null;

  const result = await db
    .select()
    .from(stores)
    .where(and(eq(stores.id, id), eq(stores.companyId, companyId)))
    .limit(1);

  return result.length > 0 ? result[0] : null;
}

export async function createStore(store: InsertStore): Promise<Store> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db.insert(stores).values(store);
  const id = result[0].insertId;
  
  const created = await db.select().from(stores).where(eq(stores.id, Number(id))).limit(1);
  return created[0];
}

// ==================== MAQUINETAS ====================

export async function getMachinesByCompany(companyId: number): Promise<Machine[]> {
  const db = await getDb();
  if (!db) return [];

  return db.select().from(machines).where(and(eq(machines.companyId, companyId), eq(machines.isActive, true)));
}

export async function getMachineById(id: number, companyId: number): Promise<Machine | null> {
  const db = await getDb();
  if (!db) return null;

  const result = await db
    .select()
    .from(machines)
    .where(and(eq(machines.id, id), eq(machines.companyId, companyId)))
    .limit(1);

  return result.length > 0 ? result[0] : null;
}

export async function createMachine(machine: InsertMachine): Promise<Machine> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db.insert(machines).values(machine);
  const id = result[0].insertId;
  
  const created = await db.select().from(machines).where(eq(machines.id, Number(id))).limit(1);
  return created[0];
}

// ==================== ORIGENS DE VENDA ====================

export async function getSalesOriginsByCompany(companyId: number): Promise<SalesOrigin[]> {
  const db = await getDb();
  if (!db) return [];

  return db.select().from(salesOrigins).where(and(eq(salesOrigins.companyId, companyId), eq(salesOrigins.isActive, true)));
}

export async function createSalesOrigin(origin: InsertSalesOrigin): Promise<SalesOrigin> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db.insert(salesOrigins).values(origin);
  const id = result[0].insertId;
  
  const created = await db.select().from(salesOrigins).where(eq(salesOrigins.id, Number(id))).limit(1);
  return created[0];
}

// ==================== ORIGENS DE HASHTAG ====================

export async function getHashtagOriginsByCompany(companyId: number): Promise<HashtagOrigin[]> {
  const db = await getDb();
  if (!db) return [];

  return db.select().from(hashtagOrigins).where(and(eq(hashtagOrigins.companyId, companyId), eq(hashtagOrigins.isActive, true)));
}

export async function createHashtagOrigin(origin: InsertHashtagOrigin): Promise<HashtagOrigin> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db.insert(hashtagOrigins).values(origin);
  const id = result[0].insertId;
  
  const created = await db.select().from(hashtagOrigins).where(eq(hashtagOrigins.id, Number(id))).limit(1);
  return created[0];
}

// ==================== VENDAS ====================

export async function createSale(sale: InsertSale): Promise<Sale> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db.insert(sales).values(sale);
  const id = result[0].insertId;
  
  const created = await db.select().from(sales).where(eq(sales.id, Number(id))).limit(1);
  return created[0];
}

export async function getSalesByCompany(companyId: number, limit?: number): Promise<Sale[]> {
  const db = await getDb();
  if (!db) return [];

  let query: any = db.select().from(sales).where(eq(sales.companyId, companyId));
  if (limit) {
    query = query.limit(limit);
  }
  
  return await query;
}

export async function getSaleById(id: number, companyId: number): Promise<Sale | null> {
  const db = await getDb();
  if (!db) return null;

  const result = await db
    .select()
    .from(sales)
    .where(and(eq(sales.id, id), eq(sales.companyId, companyId)))
    .limit(1);

  return result.length > 0 ? result[0] : null;
}

export async function cancelSale(id: number, companyId: number, reason: string): Promise<Sale> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const now = new Date();
  await db
    .update(sales)
    .set({
      isCancelled: true,
      cancellationReason: reason,
      cancelledAt: now,
      updatedAt: now,
    })
    .where(and(eq(sales.id, id), eq(sales.companyId, companyId)));

  const result = await db
    .select()
    .from(sales)
    .where(and(eq(sales.id, id), eq(sales.companyId, companyId)))
    .limit(1);

  return result[0];
}

// ==================== DELETE FUNCTIONS ====================

export async function deleteStore(id: number, companyId: number): Promise<void> {
  const db = await getDb();
  if (!db) return;

  await db.delete(stores).where(and(eq(stores.id, id), eq(stores.companyId, companyId)));
}

export async function deleteMachine(id: number, companyId: number): Promise<void> {
  const db = await getDb();
  if (!db) return;

  await db.delete(machines).where(and(eq(machines.id, id), eq(machines.companyId, companyId)));
}

export async function deleteSalesOrigin(id: number, companyId: number): Promise<void> {
  const db = await getDb();
  if (!db) return;

  await db.delete(salesOrigins).where(and(eq(salesOrigins.id, id), eq(salesOrigins.companyId, companyId)));
}

export async function deleteHashtagOrigin(id: number, companyId: number): Promise<void> {
  const db = await getDb();
  if (!db) return;

  await db.delete(hashtagOrigins).where(and(eq(hashtagOrigins.id, id), eq(hashtagOrigins.companyId, companyId)));
}


// ==================== GERENCIAMENTO DE USUÁRIOS ====================

export async function getUsersByCompany(companyId: number): Promise<User[]> {
  const db = await getDb();
  if (!db) return [];

  return db.select().from(users).where(and(eq(users.companyId, companyId), eq(users.isActive, true)));
}

export async function createUser(user: InsertUser): Promise<User> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  // Gerar um openId único para o usuário
  const openId = `local-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
  
  // Hash da senha com bcrypt
  const bcrypt = await import('bcryptjs');
  const hashedPassword = await bcrypt.hash(user.password, 10);
  
  const result = await db.insert(users).values({
    ...user,
    password: hashedPassword,
    openId,
    loginMethod: "local",
    passwordSet: false,
  });
  
  const id = result[0].insertId;
  const created = await db.select().from(users).where(eq(users.id, Number(id))).limit(1);
  return created[0];
}

export async function updateUser(id: number, companyId: number, updates: Partial<User>): Promise<User | null> {
  const db = await getDb();
  if (!db) return null;

  await db.update(users)
    .set(updates)
    .where(and(eq(users.id, id), eq(users.companyId, companyId)));

  return getUserById(id);
}

export async function deleteUser(id: number, companyId: number): Promise<void> {
  const db = await getDb();
  if (!db) return;

  await db.delete(users).where(and(eq(users.id, id), eq(users.companyId, companyId)));
}

// ==================== CONTAS A PAGAR ====================

export async function getPayableAccounts(
  companyId: number,
  filters?: { startDate?: Date; endDate?: Date; category?: string }
): Promise<PayableAccount[]> {
  const db = await getDb();
  if (!db) return [];

  let conditions = [eq(payableAccounts.companyId, companyId)];

  if (filters?.startDate && filters?.endDate) {
    const startStr = filters.startDate.toISOString().split('T')[0];
    const endStr = filters.endDate.toISOString().split('T')[0];
    conditions.push(sql`DATE(${payableAccounts.dueDate}) >= ${startStr}`);
    conditions.push(sql`DATE(${payableAccounts.dueDate}) <= ${endStr}`);
  }

  if (filters?.category) {
    conditions.push(eq(payableAccounts.category, filters.category));
  }

  return db.select().from(payableAccounts).where(and(...conditions));
}

export async function createPayableAccount(
  companyId: number,
  data: Omit<InsertPayableAccount, 'companyId'>
): Promise<PayableAccount | null> {
  const db = await getDb();
  if (!db) return null;

  const created = await db.insert(payableAccounts).values({
    ...data,
    companyId,
  });

  return getPayableAccountById(created[0].insertId, companyId);
}

export async function getPayableAccountById(id: number, companyId: number): Promise<PayableAccount | null> {
  const db = await getDb();
  if (!db) return null;

  const result = await db
    .select()
    .from(payableAccounts)
    .where(and(eq(payableAccounts.id, id), eq(payableAccounts.companyId, companyId)))
    .limit(1);

  return result[0] || null;
}

export async function updatePayableAccount(
  companyId: number,
  id: number,
  updates: Partial<PayableAccount>
): Promise<PayableAccount | null> {
  const db = await getDb();
  if (!db) return null;

  await db.update(payableAccounts)
    .set(updates)
    .where(and(eq(payableAccounts.id, id), eq(payableAccounts.companyId, companyId)));

  return getPayableAccountById(id, companyId);
}

export async function deletePayableAccount(companyId: number, id: number): Promise<void> {
  const db = await getDb();
  if (!db) return;

  await db.delete(payableAccounts)
    .where(and(eq(payableAccounts.id, id), eq(payableAccounts.companyId, companyId)));
}

// ==================== CONTAS A RECEBER ====================

export async function getReceivableAccounts(
  companyId: number,
  filters?: { startDate?: Date; endDate?: Date; category?: string }
): Promise<ReceivableAccount[]> {
  const db = await getDb();
  if (!db) return [];

  let conditions = [eq(receivableAccounts.companyId, companyId)];

  if (filters?.startDate && filters?.endDate) {
    const startStr = filters.startDate.toISOString().split('T')[0];
    const endStr = filters.endDate.toISOString().split('T')[0];
    conditions.push(sql`DATE(${receivableAccounts.dueDate}) >= ${startStr}`);
    conditions.push(sql`DATE(${receivableAccounts.dueDate}) <= ${endStr}`);
  }

  if (filters?.category) {
    conditions.push(eq(receivableAccounts.category, filters.category));
  }

  return db.select().from(receivableAccounts).where(and(...conditions));
}

export async function createReceivableAccount(
  companyId: number,
  data: Omit<InsertReceivableAccount, 'companyId'>
): Promise<ReceivableAccount | null> {
  const db = await getDb();
  if (!db) return null;

  const created = await db.insert(receivableAccounts).values({
    ...data,
    companyId,
  });

  return getReceivableAccountById(created[0].insertId, companyId);
}

export async function getReceivableAccountById(id: number, companyId: number): Promise<ReceivableAccount | null> {
  const db = await getDb();
  if (!db) return null;

  const result = await db
    .select()
    .from(receivableAccounts)
    .where(and(eq(receivableAccounts.id, id), eq(receivableAccounts.companyId, companyId)))
    .limit(1);

  return result[0] || null;
}

export async function updateReceivableAccount(
  companyId: number,
  id: number,
  updates: Partial<ReceivableAccount>
): Promise<ReceivableAccount | null> {
  const db = await getDb();
  if (!db) return null;

  await db.update(receivableAccounts)
    .set(updates)
    .where(and(eq(receivableAccounts.id, id), eq(receivableAccounts.companyId, companyId)));

  return getReceivableAccountById(id, companyId);
}

export async function deleteReceivableAccount(companyId: number, id: number): Promise<void> {
  const db = await getDb();
  if (!db) return;

  await db.delete(receivableAccounts)
    .where(and(eq(receivableAccounts.id, id), eq(receivableAccounts.companyId, companyId)));
}


// ==================== MULTI-TENANT ====================

export async function createTenant(data: {
  name: string;
  slug: string;
  email: string;
  phone?: string;
}) {
  const db = await getDb();
  if (!db) return null;

  const id = crypto.randomUUID();
  const schema_name = `schema_${data.slug.replace(/-/g, '_')}_${Date.now()}`;
  
  try {
    // Criar schema no banco de dados usando DATABASE_URL
    const mysql2 = await import('mysql2/promise');
    const connection = await mysql2.createConnection(process.env.DATABASE_URL || '');
    
    await connection.execute(`CREATE SCHEMA IF NOT EXISTS \`${schema_name}\``);
    await connection.end();
    
    // Inserir tenant com schema_name
    await db.insert(tenants).values({
      id,
      name: data.name,
      slug: data.slug,
      email: data.email,
      phone: data.phone,
      status: "active",
      schema_name: schema_name,
    });
    
    return { id, ...data, status: "active", schema_name };
  } catch (error) {
    console.error("[Database] Failed to create tenant:", error);
    return null;
  }
}

export async function getTenant(id: string) {
  const db = await getDb();
  if (!db) return null;

  const result = await db
    .select()
    .from(tenants)
    .where(eq(tenants.id, id))
    .limit(1);

  return result[0] || null;
}

export async function listTenants() {
  const db = await getDb();
  if (!db) return [];

  return await db
    .select()
    .from(tenants)
    .where(eq(tenants.status, "active"));
}

export async function getTenantsByIds(ids: string[]) {
  if (ids.length === 0) return [];
  
  const db = await getDb();
  if (!db) return [];

  const { inArray } = await import('drizzle-orm');
  return await db
    .select()
    .from(tenants)
    .where(inArray(tenants.id, ids));
}

export async function updateTenant(id: string, data: Partial<{
  name: string;
  email: string;
  phone: string;
  status: "active" | "inactive" | "suspended";
}>) {
  const db = await getDb();
  if (!db) return null;

  try {
    await db.update(tenants)
      .set({
        ...data,
        updatedAt: new Date(),
      })
      .where(eq(tenants.id, id));

    return await getTenant(id);
  } catch (error) {
    console.error("[Database] Failed to update tenant:", error);
    return null;
  }
}

export async function addUserToTenant(tenantId: string, userId: number, role: "super_admin" | "admin" | "user" | "vendor") {
  const db = await getDb();
  if (!db) return null;

  const id = crypto.randomUUID();

  try {
    await db.insert(tenantUsers).values({
      id,
      tenantId,
      userId,
      role,
      status: "active",
    });

    return { id, tenantId, userId, role, status: "active" };
  } catch (error) {
    console.error("[Database] Failed to add user to tenant:", error);
    return null;
  }
}

export async function getUserTenants(userId: number) {
  const db = await getDb();
  if (!db) return [];

  return await db
    .select()
    .from(tenantUsers)
    .where(and(
      eq(tenantUsers.userId, userId),
      eq(tenantUsers.status, "active")
    ));
}

export async function getTenantUsers(tenantId: string) {
  const db = await getDb();
  if (!db) return [];

  return await db
    .select()
    .from(tenantUsers)
    .where(and(
      eq(tenantUsers.tenantId, tenantId),
      eq(tenantUsers.status, "active")
    ));
}

export async function updateTenantUserRole(tenantId: string, userId: number, role: "super_admin" | "admin" | "user" | "vendor") {
  const db = await getDb();
  if (!db) return null;

  try {
    await db.update(tenantUsers)
      .set({
        role,
        updatedAt: new Date(),
      })
      .where(and(
        eq(tenantUsers.tenantId, tenantId),
        eq(tenantUsers.userId, userId)
      ));

    return true;
  } catch (error) {
    console.error("[Database] Failed to update tenant user role:", error);
    return null;
  }
}

export async function removeUserFromTenant(tenantId: string, userId: number) {
  const db = await getDb();
  if (!db) return null;

  try {
    await db.update(tenantUsers)
      .set({
        status: "inactive",
        updatedAt: new Date(),
      })
      .where(and(
        eq(tenantUsers.tenantId, tenantId),
        eq(tenantUsers.userId, userId)
      ));

    return true;
  } catch (error) {
    console.error("[Database] Failed to remove user from tenant:", error);
    return null;
  }
}


// ==================== LIMITE DE USUÁRIOS ====================

export async function getTenantUserLimit(tenantId: string) {
  const db = await getDb();
  if (!db) return null;

  const result = await db
    .select()
    .from(tenants)
    .where(eq(tenants.id, tenantId))
    .limit(1);

  if (!result[0]) return null;

  return {
    limit: result[0].user_limit,
    current: (await getTenantUsers(tenantId)).length,
  };
}

export async function updateTenantUserLimit(tenantId: string, newLimit: number) {
  const db = await getDb();
  if (!db) return null;

  try {
    await db.update(tenants)
      .set({
        user_limit: newLimit,
        updatedAt: new Date(),
      })
      .where(eq(tenants.id, tenantId));

    return await getTenantUserLimit(tenantId);
  } catch (error) {
    console.error("[Database] Failed to update tenant user limit:", error);
    return null;
  }
}

export async function canAddUserToTenant(tenantId: string): Promise<boolean> {
  const db = await getDb();
  if (!db) return false;

  const result = await db
    .select()
    .from(tenants)
    .where(eq(tenants.id, tenantId))
    .limit(1);

  if (!result[0]) return false;

  const currentUsers = (await getTenantUsers(tenantId)).length;
  return currentUsers < result[0].user_limit;
}
