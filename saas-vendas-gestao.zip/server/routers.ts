import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router, protectedProcedure } from "./_core/trpc";
import { z } from "zod";
import * as db from "./db";
import { TRPCError } from "@trpc/server";

// ==================== VALIDAÇÃO ====================

const loginSchema = z.object({
  email: z.string().email(),
  password: z.string().min(1),
});

const createSaleSchema = z.object({
  serialNumber: z.string().min(1),
  clientName: z.string().min(1),
  clientDocument: z.string().regex(/^\d+$/),
  storeId: z.number().int().positive(),
  machineId: z.number().int().positive(),
  saleDate: z.date(),
  isDelivery: z.boolean(),
  deliveryValue: z.number().positive().optional(),
  salesOriginId: z.number().int().positive(),
  hashtagOriginId: z.number().int().positive(),
});

const createStoreSchema = z.object({
  name: z.string().min(1),
  location: z.string().optional(),
});

const createMachineSchema = z.object({
  name: z.string().min(1),
  commissionValue: z.number().positive(),
});

const createSalesOriginSchema = z.object({
  name: z.string().min(1),
});

const createHashtagOriginSchema = z.object({
  name: z.string().min(1),
});

const createUserSchema = z.object({
  email: z.string().email(),
  password: z.string().min(6),
  name: z.string().min(1),
  role: z.enum(["admin", "user", "digital_sales"]),
  storeId: z.number().optional(),
});

const updateUserSchema = z.object({
  id: z.number(),
  name: z.string().min(1).optional(),
  role: z.enum(["admin", "user", "digital_sales"]).optional(),
  storeId: z.number().optional(),
  isActive: z.boolean().optional(),
});

const setPasswordSchema = z.object({
  newPassword: z.string().min(6),
});

const resetPasswordSchema = z.object({
  email: z.string().email(),
});

const confirmResetPasswordSchema = z.object({
  email: z.string().email(),
  newPassword: z.string().min(6),
  confirmPassword: z.string().min(6),
}).refine((data) => data.newPassword === data.confirmPassword, {
  message: "Senhas não coincidem",
  path: ["confirmPassword"],
});

// ==================== ADMIN PROCEDURE ====================

const adminProcedure = protectedProcedure.use(async ({ ctx, next }) => {
  if (ctx.user?.role !== "admin") {
    throw new TRPCError({ code: "FORBIDDEN", message: "Admin access required" });
  }
  return next({ ctx });
});

const superAdminProcedure = protectedProcedure.use(async ({ ctx, next }) => {
  if (!ctx.user) {
    throw new TRPCError({ code: "UNAUTHORIZED" });
  }
  
  // Verificar se o usuário é super_admin de algum tenant
  const userTenants = await db.getUserTenants(ctx.user.id);
  const isSuperAdmin = userTenants.some(ut => ut.role === "super_admin");
  
  if (!isSuperAdmin) {
    throw new TRPCError({ code: "FORBIDDEN", message: "Super admin access required" });
  }
  
  return next({ ctx });
});

// ==================== ROUTERS ====================

export const appRouter = router({
  system: systemRouter,
  
  // ==================== AUTH ====================
  auth: router({
    me: publicProcedure.query(async opts => {
      if (!opts.ctx.user) return null;
      const user = opts.ctx.user;
      return user;
    }),
    
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),

    login: publicProcedure
      .input(loginSchema)
      .mutation(async ({ input, ctx }) => {
        const user = await db.loginUser(input.email, input.password);
        
        if (!user) {
          throw new TRPCError({
            code: "UNAUTHORIZED",
            message: "Email ou senha incorretos",
          });
        }

        // Criar cookie de sessão JWT
        const { SignJWT } = await import("jose");
        const secret = new TextEncoder().encode(process.env.JWT_SECRET || "secret");
        
        const token = await new SignJWT({
          openId: user.openId,
          appId: process.env.VITE_APP_ID || "app",
          name: user.name || "User",
        })
          .setProtectedHeader({ alg: "HS256" })
          .setIssuedAt()
          .setExpirationTime("24h")
          .sign(secret);
        
        const cookieOptions = getSessionCookieOptions(ctx.req);
        ctx.res.cookie(COOKIE_NAME, token, {
          ...cookieOptions,
          maxAge: 24 * 60 * 60 * 1000,
        });
        
        return {
          success: true,
          needsPasswordSetup: !user.passwordSet,
          user: {
            id: user.id,
            email: user.email,
            name: user.name,
            role: user.role,
            companyId: user.companyId,
            storeId: user.storeId,
            passwordSet: user.passwordSet,
          },
        };
      }),

    setPassword: protectedProcedure
      .input(setPasswordSchema)
      .mutation(async ({ input, ctx }) => {
        if (!ctx.user) throw new TRPCError({ code: "UNAUTHORIZED" });

        const bcrypt = await import('bcryptjs');
        const hashedPassword = await bcrypt.hash(input.newPassword, 10);

        await db.updateUser(ctx.user.id, ctx.user.companyId, {
          password: hashedPassword,
          passwordSet: true,
        });

        return { success: true };
      }),

    resetPasswordRequest: publicProcedure
      .input(resetPasswordSchema)
      .mutation(async ({ input }) => {
        const user = await db.getUserByEmail(input.email);
        
        if (!user) {
          throw new TRPCError({
            code: "NOT_FOUND",
            message: "Usuario nao encontrado",
          });
        }

        return { 
          success: true,
          user: {
            id: user.id,
            name: user.name,
            role: user.role,
          }
        };
      }),

    confirmResetPassword: publicProcedure
      .input(confirmResetPasswordSchema)
      .mutation(async ({ input }) => {
        const user = await db.getUserByEmail(input.email);
        
        if (!user) {
          throw new TRPCError({
            code: "NOT_FOUND",
            message: "Usuario nao encontrado",
          });
        }

        const bcrypt = await import('bcryptjs');
        const hashedPassword = await bcrypt.hash(input.newPassword, 10);

        await db.updateUser(user.id, user.companyId, {
          password: hashedPassword,
          passwordSet: true,
        });

        return { success: true };
      }),
  }),

  // ==================== SALES ====================
  sales: router({
    create: protectedProcedure
      .input(createSaleSchema)
      .mutation(async ({ input, ctx }) => {
        if (!ctx.user) throw new TRPCError({ code: "UNAUTHORIZED" });

        // Buscar a maquineta para obter o valor da comissao
        const machine = await db.getMachineById(input.machineId, ctx.user.companyId);
        if (!machine) {
          throw new TRPCError({ code: "NOT_FOUND", message: "Maquineta nao encontrada" });
        }

        const sale = await db.createSale({
          ...input,
          deliveryValue: input.deliveryValue?.toString(),
          companyId: ctx.user.companyId,
          userId: ctx.user.id,
          commissionValue: machine.commissionValue,
        });

        return sale;
      }),

    list: protectedProcedure.query(async ({ ctx }) => {
      if (!ctx.user) throw new TRPCError({ code: "UNAUTHORIZED" });
      
      // Vendedores veem apenas suas vendas, admins e digital_sales veem todas
      if (ctx.user.role === "user") {
        const allSales = await db.getSalesByCompany(ctx.user.companyId, undefined);
        return allSales.filter((sale: any) => sale.userId === ctx.user.id);
      }
      
      return db.getSalesByCompany(ctx.user.companyId, undefined);
    }),

    getById: protectedProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input, ctx }) => {
        if (!ctx.user) throw new TRPCError({ code: "UNAUTHORIZED" });
        return db.getSaleById(input.id, ctx.user.companyId);
      }),

    cancel: protectedProcedure
      .input(z.object({ id: z.number(), reason: z.string().min(1) }))
      .mutation(async ({ input, ctx }) => {
        if (!ctx.user) throw new TRPCError({ code: "UNAUTHORIZED" });
        return db.cancelSale(input.id, ctx.user.companyId, input.reason);
      }),
  }),

  // ==================== STORES ====================
  stores: router({
    list: protectedProcedure.query(async ({ ctx }) => {
      if (!ctx.user) throw new TRPCError({ code: "UNAUTHORIZED" });
      return db.getStoresByCompany(ctx.user.companyId);
    }),

    create: adminProcedure
      .input(createStoreSchema)
      .mutation(async ({ input, ctx }) => {
        if (!ctx.user) throw new TRPCError({ code: "UNAUTHORIZED" });
        return db.createStore({
          ...input,
          companyId: ctx.user.companyId,
        });
      }),

    delete: adminProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input, ctx }) => {
        if (!ctx.user) throw new TRPCError({ code: "UNAUTHORIZED" });
        return db.deleteStore(input.id, ctx.user.companyId);
      }),
  }),

  // ==================== MACHINES ====================
  machines: router({
    list: protectedProcedure.query(async ({ ctx }) => {
      if (!ctx.user) throw new TRPCError({ code: "UNAUTHORIZED" });
      return db.getMachinesByCompany(ctx.user.companyId);
    }),

    create: adminProcedure
      .input(createMachineSchema)
      .mutation(async ({ input, ctx }) => {
        if (!ctx.user) throw new TRPCError({ code: "UNAUTHORIZED" });
        return db.createMachine({
          ...input,
          commissionValue: input.commissionValue.toString(),
          companyId: ctx.user.companyId,
        });
      }),

    delete: adminProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input, ctx }) => {
        if (!ctx.user) throw new TRPCError({ code: "UNAUTHORIZED" });
        return db.deleteMachine(input.id, ctx.user.companyId);
      }),
  }),

  // ==================== SALES ORIGINS ====================
  salesOrigins: router({
    list: protectedProcedure.query(async ({ ctx }) => {
      if (!ctx.user) throw new TRPCError({ code: "UNAUTHORIZED" });
      return db.getSalesOriginsByCompany(ctx.user.companyId);
    }),

    create: adminProcedure
      .input(createSalesOriginSchema)
      .mutation(async ({ input, ctx }) => {
        if (!ctx.user) throw new TRPCError({ code: "UNAUTHORIZED" });
        return db.createSalesOrigin({
          ...input,
          companyId: ctx.user.companyId,
        });
      }),

    delete: adminProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input, ctx }) => {
        if (!ctx.user) throw new TRPCError({ code: "UNAUTHORIZED" });
        return db.deleteSalesOrigin(input.id, ctx.user.companyId);
      }),
  }),

  // ==================== HASHTAG ORIGINS ====================
  hashtagOrigins: router({
    list: protectedProcedure.query(async ({ ctx }) => {
      if (!ctx.user) throw new TRPCError({ code: "UNAUTHORIZED" });
      return db.getHashtagOriginsByCompany(ctx.user.companyId);
    }),

    create: adminProcedure
      .input(createHashtagOriginSchema)
      .mutation(async ({ input, ctx }) => {
        if (!ctx.user) throw new TRPCError({ code: "UNAUTHORIZED" });
        return db.createHashtagOrigin({
          ...input,
          companyId: ctx.user.companyId,
        });
      }),

    delete: adminProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input, ctx }) => {
        if (!ctx.user) throw new TRPCError({ code: "UNAUTHORIZED" });
        return db.deleteHashtagOrigin(input.id, ctx.user.companyId);
      }),
  }),

  // ==================== USERS ====================
  users: router({
    list: adminProcedure.query(async ({ ctx }) => {
      if (!ctx.user) throw new TRPCError({ code: "UNAUTHORIZED" });
      return db.getUsersByCompany(ctx.user.companyId);
    }),

    create: adminProcedure
      .input(createUserSchema)
      .mutation(async ({ input, ctx }) => {
        if (!ctx.user) throw new TRPCError({ code: "UNAUTHORIZED" });
        const userData: any = {
          email: input.email,
          password: input.password,
          name: input.name,
          role: input.role,
          companyId: ctx.user.companyId,
        };
        if (input.storeId) {
          userData.storeId = input.storeId;
        }
        return db.createUser(userData);
      }),

    update: adminProcedure
      .input(updateUserSchema)
      .mutation(async ({ input, ctx }) => {
        if (!ctx.user) throw new TRPCError({ code: "UNAUTHORIZED" });
        const { id, ...updates } = input;
        return db.updateUser(id, ctx.user.companyId, updates);
      }),

    delete: adminProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input, ctx }) => {
        if (!ctx.user) throw new TRPCError({ code: "UNAUTHORIZED" });
        return db.deleteUser(input.id, ctx.user.companyId);
      }),
  }),

  // ==================== EXPORTS ====================
  exports: router({
    salesToNibo: adminProcedure
      .input(z.object({
        startDate: z.date().optional(),
        endDate: z.date().optional(),
        storeId: z.number().optional(),
      }))
      .mutation(async ({ input, ctx }) => {
        if (!ctx.user) throw new TRPCError({ code: "UNAUTHORIZED" });

        // Buscar vendas com filtros
        const allSales = await db.getSalesByCompany(ctx.user.companyId, undefined);
        
        // Filtrar por data se fornecido
        let filteredSales = allSales;
        if (input.startDate || input.endDate) {
          filteredSales = allSales.filter((sale: any) => {
            const saleDate = new Date(sale.saleDate);
            if (input.startDate && saleDate < input.startDate) return false;
            if (input.endDate && saleDate > input.endDate) return false;
            return true;
          });
        }

        // Filtrar por loja se fornecido
        if (input.storeId) {
          filteredSales = filteredSales.filter((sale: any) => sale.storeId === input.storeId);
        }

        // Excluir vendas canceladas
        filteredSales = filteredSales.filter((sale: any) => !sale.isCancelled);

        // Buscar dados relacionados
        const stores = await db.getStoresByCompany(ctx.user.companyId);
        const machines = await db.getMachinesByCompany(ctx.user.companyId);

        // Mapear dados para formato Nibo
        const niboData = filteredSales.map((sale: any) => {
          const store = stores.find((s: any) => s.id === sale.storeId);
          const machine = machines.find((m: any) => m.id === sale.machineId);
          
          // Calcular vencimento: dia 10 do mês seguinte
          const saleDate = new Date(sale.saleDate);
          const nextMonth = new Date(saleDate.getFullYear(), saleDate.getMonth() + 1, 10);
          
          return {
            "Tipo de transação": "Lançamento",
            "Nome do contato": "Stone",
            "Descrição": machine?.name || "Venda",
            "Categoria": "Receita com Vendas",
            "Valor": parseFloat(sale.commissionValue || "0"),
            "Vencimento": nextMonth,
            "Previsto para": nextMonth,
            "Competência": new Date(sale.saleDate),
            "Centro de custo": store?.name || "Loja",
            "Tipo de contato": "Cliente",
            "Anotação": sale.isDelivery ? "Entrega" : "Retirada",
          };
        });

        // Gerar Excel com xlsx
        const XLSX = await import('xlsx');
        
        // Preparar dados para o Excel
        const excelData = niboData.map((row: any) => ({
          'Tipo de transação': row['Tipo de transação'],
          'Nome do contato': row['Nome do contato'],
          'Descrição': row['Descrição'],
          'Categoria': row['Categoria'],
          'Valor': row['Valor'],
          'Vencimento': row['Vencimento'].toISOString().split('T')[0],
          'Previsto para': row['Previsto para'].toISOString().split('T')[0],
          'Competência': row['Competência'].toISOString().split('T')[0],
          'Centro de custo': row['Centro de custo'],
          'Tipo de contato': row['Tipo de contato'],
          'Anotação': row['Anotação'],
        }));

        // Criar workbook e adicionar dados
        const workbook = XLSX.utils.book_new();
        const worksheet = XLSX.utils.json_to_sheet(excelData);
        XLSX.utils.book_append_sheet(workbook, worksheet, 'Vendas');

        // Converter para buffer e depois para base64
        const buffer = XLSX.write(workbook, { type: 'buffer', bookType: 'xlsx' });
        const base64 = buffer.toString('base64');
        
        return {
          data: base64,
          filename: `exportacao-nibo-${new Date().toISOString().split('T')[0]}.xlsx`,
        };
      }),
  }),
  
  // ==================== CONTAS A PAGAR ====================
  payableAccounts: router({
    list: protectedProcedure
      .input(z.object({
        startDate: z.date().optional(),
        endDate: z.date().optional(),
        category: z.string().optional(),
      }))
      .query(async ({ ctx, input }) => {
        return db.getPayableAccounts(ctx.user.companyId, input);
      }),
    
    create: protectedProcedure
      .input(z.object({
        contactName: z.string().min(1),
        description: z.string().optional(),
        category: z.string().min(1),
        dueDate: z.date(),
        competenceDate: z.date(),
        value: z.number().positive(),
        costCenter: z.string().optional(),
        notes: z.string().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        const data = { ...input, value: input.value.toString() };
        return db.createPayableAccount(ctx.user.companyId, data);
      }),
    
    update: protectedProcedure
      .input(z.object({
        id: z.number().int().positive(),
        status: z.enum(['pending', 'paid', 'overdue']).optional(),
        value: z.number().positive().optional(),
        dueDate: z.date().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        const updates: any = {};
        if (input.status) updates.status = input.status;
        if (input.dueDate) updates.dueDate = input.dueDate;
        if (input.value) updates.value = input.value.toString();
        return db.updatePayableAccount(ctx.user.companyId, input.id, updates);
      }),
    
    delete: protectedProcedure
      .input(z.number().int().positive())
      .mutation(async ({ ctx, input }) => {
        return db.deletePayableAccount(ctx.user.companyId, input);
      }),
  }),
  
  // ==================== CONTAS A RECEBER ====================
  receivableAccounts: router({
    list: protectedProcedure
      .input(z.object({
        startDate: z.date().optional(),
        endDate: z.date().optional(),
        category: z.string().optional(),
      }))
      .query(async ({ ctx, input }) => {
        return db.getReceivableAccounts(ctx.user.companyId, input);
      }),
    
    create: protectedProcedure
      .input(z.object({
        contactName: z.string().min(1),
        description: z.string().optional(),
        category: z.string().min(1),
        dueDate: z.date(),
        competenceDate: z.date(),
        value: z.number().positive(),
        costCenter: z.string().optional(),
        notes: z.string().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        const data = { ...input, value: input.value.toString() };
        return db.createReceivableAccount(ctx.user.companyId, data);
      }),
    
    update: protectedProcedure
      .input(z.object({
        id: z.number().int().positive(),
        status: z.enum(['pending', 'received', 'overdue']).optional(),
        value: z.number().positive().optional(),
        dueDate: z.date().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        const updates: any = {};
        if (input.status) updates.status = input.status;
        if (input.dueDate) updates.dueDate = input.dueDate;
        if (input.value) updates.value = input.value.toString();
        return db.updateReceivableAccount(ctx.user.companyId, input.id, updates);
      }),
    
    delete: protectedProcedure
      .input(z.number().int().positive())
      .mutation(async ({ ctx, input }) => {
        return db.deleteReceivableAccount(ctx.user.companyId, input);
      }),
  }),

  // ==================== MULTI-TENANT ADMIN ====================
  tenants: router({
    list: adminProcedure.query(async ({ ctx }) => {
      if (!ctx.user) throw new TRPCError({ code: "UNAUTHORIZED" });
      // Retornar apenas os tenants onde o usuário tem acesso
      const userTenants = await db.getUserTenants(ctx.user.id);
      if (userTenants.length === 0) {
        return [];
      }
      const tenantIds = userTenants.map(ut => ut.tenantId);
      return db.getTenantsByIds(tenantIds);
    }),

    listAll: superAdminProcedure.query(async ({ ctx }) => {
      return db.listTenants();
    }),

    create: adminProcedure
      .input(z.object({
        name: z.string().min(1),
        slug: z.string().min(1).regex(/^[a-z0-9-]+$/),
        email: z.string().email(),
        phone: z.string().optional(),
      }))
      .mutation(async ({ input, ctx }) => {
        if (!ctx.user) throw new TRPCError({ code: "UNAUTHORIZED" });

        const tenant = await db.createTenant(input);
        if (!tenant) {
          throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Erro ao criar empresa" });
        }

        // Adicionar criador como super_admin do tenant
        await db.addUserToTenant(tenant.id, ctx.user.id, "super_admin");

        return tenant;
      }),

    update: superAdminProcedure
      .input(z.object({
        id: z.string(),
        name: z.string().min(1).optional(),
        email: z.string().email().optional(),
        phone: z.string().optional(),
        status: z.enum(["active", "inactive", "suspended"]).optional(),
      }))
      .mutation(async ({ input, ctx }) => {

        const tenant = await db.updateTenant(input.id, input);
        if (!tenant) {
          throw new TRPCError({ code: "NOT_FOUND", message: "Empresa não encontrada" });
        }

        return tenant;
      }),

    getById: superAdminProcedure
      .input(z.object({ id: z.string() }))
      .query(async ({ input, ctx }) => {
        
        const tenant = await db.getTenant(input.id);
        if (!tenant) {
          throw new TRPCError({ code: "NOT_FOUND", message: "Empresa não encontrada" });
        }

        return tenant;
      }),
  }),

  tenantUsers: router({
    listByTenant: superAdminProcedure
      .input(z.object({ tenantId: z.string() }))
      .query(async ({ input, ctx }) => {

        return db.getTenantUsers(input.tenantId);
      }),

    listByUser: protectedProcedure.query(async ({ ctx }) => {
      if (!ctx.user) throw new TRPCError({ code: "UNAUTHORIZED" });

      return db.getUserTenants(ctx.user.id);
    }),

    addToTenant: superAdminProcedure
      .input(z.object({
        tenantId: z.string(),
        userId: z.number(),
        role: z.enum(["super_admin", "admin", "user", "vendor"]),
      }))
      .mutation(async ({ input, ctx }) => {

        const tenantUser = await db.addUserToTenant(input.tenantId, input.userId, input.role);
        if (!tenantUser) {
          throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Erro ao adicionar usuário à empresa" });
        }

        return tenantUser;
      }),

    updateRole: superAdminProcedure
      .input(z.object({
        tenantId: z.string(),
        userId: z.number(),
        role: z.enum(["super_admin", "admin", "user", "vendor"]),
      }))
      .mutation(async ({ input, ctx }) => {

        const success = await db.updateTenantUserRole(input.tenantId, input.userId, input.role);
        if (!success) {
          throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Erro ao atualizar role do usuário" });
        }

        return { success: true };
      }),

    removeFromTenant: superAdminProcedure
      .input(z.object({
        tenantId: z.string(),
        userId: z.number(),
      }))
      .mutation(async ({ input, ctx }) => {

        const success = await db.removeUserFromTenant(input.tenantId, input.userId);
        if (!success) {
          throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Erro ao remover usuário da empresa" });
        }

        return { success: true };
      }),

    getUserLimit: superAdminProcedure
      .input(z.object({ tenantId: z.string() }))
      .query(async ({ input }) => {
        return await db.getTenantUserLimit(input.tenantId);
      }),

    updateUserLimit: superAdminProcedure
      .input(z.object({
        tenantId: z.string(),
        newLimit: z.number().min(1).max(1000),
      }))
      .mutation(async ({ input }) => {
        const result = await db.updateTenantUserLimit(input.tenantId, input.newLimit);
        if (!result) {
          throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Erro ao atualizar limite de usuarios" });
        }
        return result;
      }),
  }),
});
